import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { NearbyFacility } from '../types';
import { fetchDirections, DirectionsResult, RouteStep } from '../services/api';

interface DirectionsModalProps {
  facility: NearbyFacility;
  userLocation: {
    lat: number;
    lng: number;
    address: string;
  };
  onClose: () => void;
  onCallFacility?: (phone: string) => void;
}

export const DirectionsModal: React.FC<DirectionsModalProps> = ({
  facility,
  userLocation,
  onClose,
  onCallFacility,
}) => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const routePolylineRef = useRef<L.Polyline | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);

  const [mode, setMode] = useState<'emergency' | 'driving' | 'walking'>('emergency');
  const [directionsData, setDirectionsData] = useState<DirectionsResult['route'] | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [activeStepIndex, setActiveStepIndex] = useState<number>(0);
  const [isSimulatingNav, setIsSimulatingNav] = useState<boolean>(false);

  // Fetch directions whenever transport mode changes
  useEffect(() => {
    let isCancelled = false;
    const loadRoute = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const res = await fetchDirections({
          origin: {
            lat: userLocation.lat,
            lng: userLocation.lng,
            address: userLocation.address,
          },
          destination: {
            lat: facility.lat,
            lng: facility.lng,
            name: facility.name,
            address: facility.address,
          },
          facilityId: facility.id,
          mode,
        });

        if (!isCancelled) {
          setDirectionsData(res.route);
          setActiveStepIndex(0);
        }
      } catch (err: any) {
        if (!isCancelled) {
          console.error('Failed to fetch directions:', err);
          setError('Could not calculate real-time route. Displaying direct path.');
        }
      } finally {
        if (!isCancelled) setIsLoading(false);
      }
    };

    loadRoute();
    return () => {
      isCancelled = true;
    };
  }, [facility, userLocation, mode]);

  // Initialize or update Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        zoomControl: true,
        attributionControl: false,
      }).setView([userLocation.lat, userLocation.lng], 14);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
      }).addTo(map);

      const markersGroup = L.layerGroup().addTo(map);
      markersLayerRef.current = markersGroup;
      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;
    const markersGroup = markersLayerRef.current;
    if (!map || !markersGroup) return;

    markersGroup.clearLayers();

    // Custom Origin Icon (Pulsing User GPS Marker)
    const originIcon = L.divIcon({
      className: 'custom-user-marker',
      html: `
        <div style="position: relative; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center;">
          <div style="position: absolute; width: 26px; height: 26px; background-color: rgba(0, 74, 198, 0.35); border-radius: 50%; animation: pulse-ring 2s infinite;"></div>
          <div style="width: 16px; height: 16px; background-color: #004ac6; border: 3px solid #ffffff; border-radius: 50%; box-shadow: 0 2px 6px rgba(0,0,0,0.3);"></div>
        </div>
      `,
      iconSize: [26, 26],
      iconAnchor: [13, 13],
    });

    // Custom Destination Icon
    const getDestColor = () => {
      if (facility.category === 'hospital') return '#004ac6';
      if (facility.category === 'fire') return '#bb0112';
      if (facility.category === 'police') return '#2563eb';
      return '#006243';
    };

    const destIcon = L.divIcon({
      className: 'custom-dest-marker',
      html: `
        <div style="position: relative; width: 34px; height: 34px; background-color: ${getDestColor()}; border: 3px solid #ffffff; border-radius: 50%; box-shadow: 0 4px 10px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; color: white;">
          <span class="material-symbols-outlined" style="font-size: 18px;">local_hospital</span>
        </div>
      `,
      iconSize: [34, 34],
      iconAnchor: [17, 17],
    });

    const origMarker = L.marker([userLocation.lat, userLocation.lng], { icon: originIcon })
      .bindPopup(`<b>Your Live Location</b><br>${userLocation.address}`)
      .addTo(markersGroup);

    const destMarker = L.marker([facility.lat, facility.lng], { icon: destIcon })
      .bindPopup(`<b>${facility.name}</b><br>${facility.address}`)
      .addTo(markersGroup);

    // Draw route polyline if coordinates exist
    if (routePolylineRef.current) {
      map.removeLayer(routePolylineRef.current);
      routePolylineRef.current = null;
    }

    if (directionsData && directionsData.polylineCoords.length > 0) {
      const polyline = L.polyline(directionsData.polylineCoords, {
        color: mode === 'emergency' ? '#004ac6' : '#2563eb',
        weight: 6,
        opacity: 0.85,
        lineCap: 'round',
        lineJoin: 'round',
        dashArray: mode === 'walking' ? '8, 8' : undefined,
      }).addTo(map);

      routePolylineRef.current = polyline;

      // Fit map bounds to encompass both origin and destination
      map.fitBounds(polyline.getBounds(), { padding: [40, 40] });
    } else {
      const bounds = L.latLngBounds([
        [userLocation.lat, userLocation.lng],
        [facility.lat, facility.lng],
      ]);
      map.fitBounds(bounds, { padding: [50, 50] });
    }

    setTimeout(() => {
      map.invalidateSize();
    }, 150);
  }, [directionsData, facility, userLocation, mode]);

  // Simulated GPS turn-by-turn navigation progression
  useEffect(() => {
    let timer: any;
    if (isSimulatingNav && directionsData && directionsData.steps.length > 0) {
      timer = setInterval(() => {
        setActiveStepIndex((prev) => {
          if (prev >= directionsData.steps.length - 1) {
            setIsSimulatingNav(false);
            return prev;
          }
          return prev + 1;
        });
      }, 4000);
    }
    return () => clearInterval(timer);
  }, [isSimulatingNav, directionsData]);

  const openExternalMaps = (platform: 'google' | 'apple') => {
    const dLat = facility.lat;
    const dLng = facility.lng;
    const sLat = userLocation.lat;
    const sLng = userLocation.lng;

    let url = '';
    if (platform === 'google') {
      url = `https://www.google.com/maps/dir/?api=1&origin=${sLat},${sLng}&destination=${dLat},${dLng}&travelmode=driving`;
    } else {
      url = `https://maps.apple.com/?saddr=${sLat},${sLng}&daddr=${dLat},${dLng}&dirflg=d`;
    }
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const getStepIcon = (iconType: RouteStep['icon']) => {
    switch (iconType) {
      case 'start':
        return 'my_location';
      case 'turn-left':
        return 'turn_left';
      case 'turn-right':
        return 'turn_right';
      case 'merge':
        return 'merge';
      case 'destination':
        return 'flag';
      default:
        return 'straight';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 md:p-6 animate-fadeIn">
      <div className="bg-white w-full max-w-4xl max-h-[92vh] rounded-2xl shadow-2xl border border-[#c3c6d7] flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 md:p-5 border-b border-[#c3c6d7] bg-[#f0f3ff] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#004ac6] text-white flex items-center justify-center shadow-sm">
              <span className="material-symbols-outlined text-xl">directions</span>
            </div>
            <div>
              <h2 className="text-lg font-bold text-[#111c2d]">Live Directions & GPS Route</h2>
              <p className="text-xs text-[#434655]">
                To <span className="font-semibold text-[#111c2d]">{facility.name}</span> • {facility.address}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white border border-[#c3c6d7] flex items-center justify-center text-[#434655] hover:bg-[#d8e3fb] transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-lg">close</span>
          </button>
        </div>

        {/* Modal Body: Split Map & Steps */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden min-h-[380px]">
          {/* Left Column: Leaflet Interactive Map */}
          <div className="md:col-span-7 h-64 md:h-full relative bg-[#eef2f9] flex flex-col border-b md:border-b-0 md:border-r border-[#c3c6d7]">
            <div ref={mapContainerRef} className="w-full h-full z-0" />

            {/* Map Overlay Stats Pill */}
            {directionsData && !isLoading && (
              <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3.5 py-2 rounded-xl shadow-lg border border-[#c3c6d7] z-10 flex items-center gap-3 text-xs">
                <div className="flex flex-col">
                  <span className="text-[10px] text-[#737686] uppercase font-bold">Estimated Time</span>
                  <span className="text-base font-extrabold text-[#004ac6]">
                    {directionsData.estimatedDurationText}
                  </span>
                </div>
                <div className="w-px h-6 bg-[#c3c6d7]" />
                <div className="flex flex-col">
                  <span className="text-[10px] text-[#737686] uppercase font-bold">Distance</span>
                  <span className="text-sm font-bold text-[#111c2d]">
                    {directionsData.totalDistanceText}
                  </span>
                </div>
                {mode === 'emergency' && (
                  <span className="bg-[#ffdad6] text-[#ba1a1a] font-bold text-[10px] px-2 py-0.5 rounded-full uppercase">
                    Priority Siren
                  </span>
                )}
              </div>
            )}

            {/* Map Controls Floating in Bottom Corner */}
            <div className="absolute bottom-3 left-3 right-3 flex justify-between items-center z-10">
              <div className="bg-white/95 backdrop-blur-md px-2.5 py-1.5 rounded-lg border border-[#c3c6d7] shadow text-[11px] text-[#434655] flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-[#004ac6] animate-pulse"></span>
                <span>Live GPS Origin: {userLocation.lat.toFixed(4)}, {userLocation.lng.toFixed(4)}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Mode Selectors & Step-by-Step Directions */}
          <div className="md:col-span-5 flex flex-col h-full bg-[#f9f9ff] overflow-hidden">
            {/* Transport Mode Switcher */}
            <div className="p-3 border-b border-[#c3c6d7] bg-white flex gap-1.5">
              <button
                onClick={() => setMode('emergency')}
                className={`flex-1 py-2 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-colors cursor-pointer ${
                  mode === 'emergency'
                    ? 'bg-[#004ac6] text-white shadow-xs'
                    : 'bg-[#f0f3ff] text-[#434655] hover:bg-[#d8e3fb]'
                }`}
              >
                <span className="material-symbols-outlined text-base">emergency</span>
                <span>Emergency</span>
              </button>

              <button
                onClick={() => setMode('driving')}
                className={`flex-1 py-2 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-colors cursor-pointer ${
                  mode === 'driving'
                    ? 'bg-[#004ac6] text-white shadow-xs'
                    : 'bg-[#f0f3ff] text-[#434655] hover:bg-[#d8e3fb]'
                }`}
              >
                <span className="material-symbols-outlined text-base">directions_car</span>
                <span>Driving</span>
              </button>

              <button
                onClick={() => setMode('walking')}
                className={`flex-1 py-2 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-colors cursor-pointer ${
                  mode === 'walking'
                    ? 'bg-[#004ac6] text-white shadow-xs'
                    : 'bg-[#f0f3ff] text-[#434655] hover:bg-[#d8e3fb]'
                }`}
              >
                <span className="material-symbols-outlined text-base">directions_walk</span>
                <span>Walking</span>
              </button>
            </div>

            {/* Turn-by-Turn Steps List */}
            <div className="flex-1 overflow-y-auto p-3.5 flex flex-col gap-2.5">
              {isLoading ? (
                <div className="flex flex-col items-center justify-center h-48 text-[#737686] gap-2">
                  <div className="w-8 h-8 border-3 border-[#004ac6] border-t-transparent rounded-full animate-spin"></div>
                  <span className="text-xs font-semibold">Calculating best route with traffic...</span>
                </div>
              ) : directionsData && directionsData.steps.length > 0 ? (
                directionsData.steps.map((step, idx) => {
                  const isActive = idx === activeStepIndex;
                  const isPassed = idx < activeStepIndex;
                  return (
                    <div
                      key={idx}
                      onClick={() => setActiveStepIndex(idx)}
                      className={`p-3 rounded-xl border text-xs transition-all cursor-pointer flex items-start gap-2.5 ${
                        isActive
                          ? 'bg-[#e7eeff] border-[#004ac6] ring-1 ring-[#004ac6] shadow-xs'
                          : isPassed
                          ? 'bg-[#f0f3ff]/60 border-[#c3c6d7] opacity-70'
                          : 'bg-white border-[#c3c6d7] hover:border-[#004ac6]/50'
                      }`}
                    >
                      <div
                        className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                          isActive
                            ? 'bg-[#004ac6] text-white'
                            : isPassed
                            ? 'bg-[#85f8c4] text-[#002114]'
                            : 'bg-[#dee8ff] text-[#004ac6]'
                        }`}
                      >
                        <span className="material-symbols-outlined text-base">
                          {getStepIcon(step.icon)}
                        </span>
                      </div>

                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <p className={`font-semibold text-sm ${isActive ? 'text-[#004ac6]' : 'text-[#111c2d]'}`}>
                            {step.instruction}
                          </p>
                          <span className="text-[11px] font-bold text-[#434655] shrink-0 ml-2">
                            {step.distance}
                          </span>
                        </div>
                        {step.streetName && (
                          <p className="text-[11px] text-[#737686] mt-0.5">
                            Via {step.streetName}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-10 text-xs text-[#737686]">
                  No step instructions available.
                </div>
              )}
            </div>

            {/* Navigation Guidance & External Actions Footer */}
            <div className="p-3 border-t border-[#c3c6d7] bg-white flex flex-col gap-2">
              <div className="flex gap-2">
                <button
                  onClick={() => setIsSimulatingNav((prev) => !prev)}
                  className={`flex-1 py-2.5 px-3 rounded-xl font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                    isSimulatingNav
                      ? 'bg-[#bb0112] text-white'
                      : 'bg-[#004ac6] text-white hover:bg-[#003ea8]'
                  }`}
                >
                  <span className="material-symbols-outlined text-base">
                    {isSimulatingNav ? 'pause_circle' : 'navigation'}
                  </span>
                  <span>{isSimulatingNav ? 'Stop Live Guidance' : 'Start Live GPS Guidance'}</span>
                </button>

                <button
                  onClick={() => {
                    if (onCallFacility) onCallFacility(facility.phone);
                    else alert(`Calling ${facility.name}: ${facility.phone}`);
                  }}
                  className="w-10 h-10 rounded-xl border border-[#c3c6d7] flex items-center justify-center text-[#111c2d] hover:bg-[#f0f3ff] transition-colors"
                  title="Call Facility"
                >
                  <span className="material-symbols-outlined text-lg">call</span>
                </button>
              </div>

              {/* External Maps Links */}
              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => openExternalMaps('google')}
                  className="flex-1 py-1.5 px-2 bg-[#f0f3ff] hover:bg-[#dee8ff] rounded-lg text-[11px] font-semibold text-[#004ac6] flex items-center justify-center gap-1 transition-colors cursor-pointer border border-[#c3c6d7]"
                >
                  <span className="material-symbols-outlined text-xs">map</span>
                  <span>Open in Google Maps</span>
                </button>
                <button
                  onClick={() => openExternalMaps('apple')}
                  className="flex-1 py-1.5 px-2 bg-[#f0f3ff] hover:bg-[#dee8ff] rounded-lg text-[11px] font-semibold text-[#004ac6] flex items-center justify-center gap-1 transition-colors cursor-pointer border border-[#c3c6d7]"
                >
                  <span className="material-symbols-outlined text-xs">open_in_new</span>
                  <span>Open in Apple Maps</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
