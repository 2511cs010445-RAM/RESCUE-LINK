import React, { useState, useEffect, useRef } from 'react';
import L from 'leaflet';
import { NearbyFacility, FacilityCategory } from '../types';
import { fetchFacilities, reverseGeocode } from '../services/api';
import { DirectionsModal } from './DirectionsModal';

interface LocateViewProps {
  facilities: NearbyFacility[];
  initialCategory?: FacilityCategory | 'all';
  onOpenDirections?: (facility: NearbyFacility) => void;
  onCallFacility?: (phone: string) => void;
}

export const LocateView: React.FC<LocateViewProps> = ({
  facilities: initialFacilities,
  initialCategory = 'all',
  onOpenDirections,
  onCallFacility,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<FacilityCategory | 'all'>(initialCategory);
  const [searchQuery, setSearchQuery] = useState('');
  const [facilities, setFacilities] = useState<NearbyFacility[]>(initialFacilities);
  const [selectedFacilityId, setSelectedFacilityId] = useState<string>(initialFacilities[0]?.id || 'fac-narayana-mallareddy');
  const [directionsFacility, setDirectionsFacility] = useState<NearbyFacility | null>(null);

  // User live GPS location state
  const [userLocation, setUserLocation] = useState<{
    lat: number;
    lng: number;
    address: string;
    accuracy?: number;
  }>({
    lat: 47.6062,
    lng: -122.3321,
    address: 'Seattle Downtown Public Safety Sector',
    accuracy: 5,
  });
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [locationStatus, setLocationStatus] = useState<'acquiring' | 'locked' | 'default'>('default');

  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);

  // Update category when prop changes
  useEffect(() => {
    if (initialCategory) {
      setSelectedCategory(initialCategory);
    }
  }, [initialCategory]);

  // Real browser geolocation acquisition
  const acquireLiveLocation = () => {
    if (!navigator.geolocation) {
      return;
    }

    setIsLocating(true);
    setLocationStatus('acquiring');

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude, accuracy } = pos.coords;
        let addr = `${latitude.toFixed(4)}°N, ${longitude.toFixed(4)}°W`;

        try {
          const rev = await reverseGeocode(latitude, longitude);
          if (rev && rev.address) {
            addr = rev.shortAddress || rev.address;
          }
        } catch {
          // Fallback coordinate string
        }

        setUserLocation({
          lat: latitude,
          lng: longitude,
          address: addr,
          accuracy: Math.round(accuracy),
        });
        setLocationStatus('locked');
        setIsLocating(false);

        // Fetch proximity sorted facilities from backend
        try {
          const updatedFacilities = await fetchFacilities(
            selectedCategory === 'all' ? undefined : selectedCategory,
            searchQuery || undefined,
            latitude,
            longitude
          );
          setFacilities(updatedFacilities);
        } catch (e) {
          console.warn('Facilities proximity refresh error:', e);
        }

        // Center map to user
        if (mapInstanceRef.current) {
          mapInstanceRef.current.flyTo([latitude, longitude], 15, { duration: 1.2 });
        }
      },
      (err) => {
        console.warn('Geolocation permission notice:', err.message);
        setIsLocating(false);
        setLocationStatus('default');
      },
      { enableHighAccuracy: true, timeout: 8000, maximumAge: 10000 }
    );
  };

  // Run on mount once to check for geolocation
  useEffect(() => {
    acquireLiveLocation();
  }, []);

  // Update facilities list when category or search changes with user location
  useEffect(() => {
    let isCancelled = false;
    const loadFacilities = async () => {
      try {
        const res = await fetchFacilities(
          selectedCategory === 'all' ? undefined : selectedCategory,
          searchQuery || undefined,
          userLocation.lat,
          userLocation.lng
        );
        if (!isCancelled) {
          setFacilities(res);
        }
      } catch {
        // Fallback
        if (!isCancelled) {
          const filtered = initialFacilities.filter((fac) => {
            const matchesCategory = selectedCategory === 'all' || fac.category === selectedCategory;
            const matchesSearch =
              fac.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
              fac.address.toLowerCase().includes(searchQuery.toLowerCase());
            return matchesCategory && matchesSearch;
          });
          setFacilities(filtered);
        }
      }
    };

    loadFacilities();
    return () => {
      isCancelled = true;
    };
  }, [selectedCategory, searchQuery, userLocation.lat, userLocation.lng]);

  // Leaflet Map Initialization and updates
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        zoomControl: false,
        attributionControl: false,
      }).setView([userLocation.lat, userLocation.lng], 14);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
      }).addTo(map);

      const markersGroup = L.layerGroup().addTo(map);
      markersLayerRef.current = markersGroup;
      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;
    const markersGroup = markersLayerRef.current;
    if (!map || !markersGroup) return;

    markersGroup.clearLayers();

    // User location pulsing marker
    const userMarkerIcon = L.divIcon({
      className: 'user-gps-marker',
      html: `
        <div style="position: relative; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center;">
          <div style="position: absolute; width: 24px; height: 24px; background-color: rgba(0, 74, 198, 0.25); border-radius: 50%; animation: pulse 2s infinite;"></div>
          <div style="width: 14px; height: 14px; background-color: #004ac6; border: 2.5px solid #ffffff; border-radius: 50%; box-shadow: 0 2px 6px rgba(0,0,0,0.3);"></div>
        </div>
      `,
      iconSize: [24, 24],
      iconAnchor: [12, 12],
    });

    const userMarker = L.marker([userLocation.lat, userLocation.lng], { icon: userMarkerIcon })
      .bindPopup(
        `<div style="font-family: sans-serif; padding: 2px;">
          <b style="color: #004ac6;">Your Live Location</b>
          <div style="font-size: 11px; color: #434655;">${userLocation.address}</div>
        </div>`
      )
      .addTo(markersGroup);

    userMarkerRef.current = userMarker;

    // Facility Markers
    facilities.forEach((fac) => {
      const isSelected = fac.id === selectedFacilityId;

      let pinBg = '#004ac6'; // Hospital blue
      let iconSymbol = 'local_hospital';

      if (fac.category === 'fire') {
        pinBg = '#ba1a1a';
        iconSymbol = 'local_fire_department';
      } else if (fac.category === 'police') {
        pinBg = '#003ea8';
        iconSymbol = 'local_police';
      } else if (fac.category === 'ambulance') {
        pinBg = '#006243';
        iconSymbol = 'ambulance';
      }

      const markerHtml = `
        <div style="
          background-color: ${pinBg};
          color: white;
          width: ${isSelected ? '38px' : '32px'};
          height: ${isSelected ? '38px' : '32px'};
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 4px 10px rgba(0,0,0,0.25);
          border: 2px solid #ffffff;
          transform: ${isSelected ? 'scale(1.1)' : 'scale(1.0)'};
          transition: transform 0.2s;
        ">
          <span class="material-symbols-outlined" style="font-size: ${isSelected ? '20px' : '17px'}; font-variation-settings: 'FILL' 1;">
            ${iconSymbol}
          </span>
        </div>
      `;

      const customIcon = L.divIcon({
        className: `facility-pin-${fac.id}`,
        html: markerHtml,
        iconSize: isSelected ? [38, 38] : [32, 32],
        iconAnchor: isSelected ? [19, 19] : [16, 16],
      });

      const marker = L.marker([fac.lat, fac.lng], { icon: customIcon }).addTo(markersGroup);

      const popupHtml = `
        <div style="font-family: sans-serif; min-width: 200px; padding: 2px;">
          <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 2px;">
            <span style="font-size: 9px; font-weight: bold; text-transform: uppercase; color: ${pinBg};">${fac.category}</span>
            <span style="font-size: 11px; font-weight: bold; color: #004ac6;">${fac.distance}</span>
          </div>
          <b style="font-size: 13px; color: #111c2d; display: block; line-height: 1.2;">${fac.name}</b>
          <div style="font-size: 11px; color: #434655; margin-top: 2px;">${fac.address}</div>
          <div style="font-size: 11px; color: #111c2d; margin-top: 4px; font-weight: 600;">Tel: ${fac.phone}</div>
        </div>
      `;

      marker.bindPopup(popupHtml);

      marker.on('click', () => {
        setSelectedFacilityId(fac.id);
      });

      if (isSelected) {
        marker.openPopup();
      }
    });

    setTimeout(() => {
      map.invalidateSize();
    }, 150);
  }, [facilities, selectedFacilityId, userLocation]);

  const handleSelectFacility = (fac: NearbyFacility) => {
    setSelectedFacilityId(fac.id);
    if (mapInstanceRef.current) {
      mapInstanceRef.current.flyTo([fac.lat, fac.lng], 15, { duration: 1.0 });
    }
  };

  const handleOpenDirections = (fac: NearbyFacility) => {
    setDirectionsFacility(fac);
    if (onOpenDirections) {
      onOpenDirections(fac);
    }
  };

  const handleDialFacility = (phone: string) => {
    if (onCallFacility) {
      onCallFacility(phone);
    } else {
      window.location.href = `tel:${phone}`;
    }
  };

  const selectedFacility = facilities.find((f) => f.id === selectedFacilityId) || facilities[0];

  // Nearest of each category for Quick Jump
  const nearestHospital = initialFacilities.find((f) => f.category === 'hospital');
  const nearestPolice = initialFacilities.find((f) => f.category === 'police');
  const nearestFire = initialFacilities.find((f) => f.category === 'fire');
  const nearestAmbulance = initialFacilities.find((f) => f.category === 'ambulance');

  const getCategoryBadgeClass = (category: FacilityCategory) => {
    switch (category) {
      case 'hospital':
        return 'bg-[#dbe1ff] text-[#004ac6]';
      case 'fire':
        return 'bg-[#ffdad6] text-[#93000a]';
      case 'police':
        return 'bg-[#dee8ff] text-[#003ea8]';
      case 'ambulance':
        return 'bg-[#bdffdc] text-[#005137]';
      default:
        return 'bg-[#f0f3ff] text-[#111c2d]';
    }
  };

  return (
    <div className="flex flex-1 pt-16 h-[calc(100vh-64px)] relative overflow-hidden flex-col md:flex-row">
      {/* Sidebar Location List */}
      <aside className="w-full md:w-[420px] lg:w-[460px] h-full bg-[#f9f9ff] border-r border-[#c3c6d7] flex flex-col shadow-sm z-10 shrink-0">
        {/* Search & Category Filter Header */}
        <div className="p-4 md:p-5 border-b border-[#c3c6d7] bg-[#f0f3ff] flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold text-[#111c2d]">Emergency Services</h1>
            {/* Live GPS status pill */}
            <button
              onClick={acquireLiveLocation}
              disabled={isLocating}
              className={`px-2.5 py-1 rounded-full text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
                locationStatus === 'locked'
                  ? 'bg-[#bdffdc] text-[#005137] border-[#007d57]/30'
                  : 'bg-white text-[#004ac6] border-[#004ac6]/40 hover:bg-[#d8e3fb]'
              }`}
              title="Click to refresh your live GPS location"
            >
              <span
                className={`material-symbols-outlined text-sm ${
                  isLocating ? 'animate-spin' : locationStatus === 'locked' ? 'text-[#007d57]' : ''
                }`}
              >
                {isLocating ? 'sync' : 'my_location'}
              </span>
              <span>{isLocating ? 'Locating...' : locationStatus === 'locked' ? 'GPS Active' : 'Locate Me'}</span>
            </button>
          </div>

          {/* Current Live Address Box */}
          <div className="bg-white px-3 py-2 rounded-lg border border-[#c3c6d7] flex items-center gap-2 text-xs text-[#434655]">
            <span className="material-symbols-outlined text-sm text-[#004ac6]">location_on</span>
            <span className="truncate flex-1 font-medium">{userLocation.address}</span>
            {userLocation.accuracy && (
              <span className="text-[10px] text-[#737686] shrink-0 font-semibold">±{userLocation.accuracy}m</span>
            )}
          </div>

          {/* Nearest 4 Services Quick Jump Bar */}
          <div className="bg-white rounded-xl p-2.5 border border-[#c3c6d7] flex flex-col gap-1.5 shadow-xs">
            <span className="text-[10px] font-bold text-[#434655] uppercase tracking-wider flex items-center gap-1">
              <span className="material-symbols-outlined text-xs text-[#004ac6]">near_me</span>
              Nearest 4 Emergency Services
            </span>

            <div className="grid grid-cols-4 gap-1.5">
              {/* Closest Hospital */}
              <button
                onClick={() => {
                  setSelectedCategory('hospital');
                  if (nearestHospital) handleSelectFacility(nearestHospital);
                }}
                className={`p-1.5 rounded-lg border flex flex-col items-center justify-center text-center transition-all cursor-pointer ${
                  selectedCategory === 'hospital'
                    ? 'bg-[#dbe1ff] border-[#004ac6] text-[#004ac6]'
                    : 'bg-[#f9f9ff] border-[#c3c6d7] hover:bg-[#dbe1ff]/40 text-[#111c2d]'
                }`}
                title={nearestHospital ? `Hospital: ${nearestHospital.name}` : 'Hospital'}
              >
                <span className="material-symbols-outlined text-base text-[#004ac6]">local_hospital</span>
                <span className="text-[11px] font-bold mt-0.5 leading-tight">Hospital</span>
                <span className="text-[9px] font-semibold text-[#004ac6] truncate w-full">
                  {nearestHospital ? nearestHospital.distance : 'ER'}
                </span>
              </button>

              {/* Closest Police */}
              <button
                onClick={() => {
                  setSelectedCategory('police');
                  if (nearestPolice) handleSelectFacility(nearestPolice);
                }}
                className={`p-1.5 rounded-lg border flex flex-col items-center justify-center text-center transition-all cursor-pointer ${
                  selectedCategory === 'police'
                    ? 'bg-[#dee8ff] border-[#003ea8] text-[#003ea8]'
                    : 'bg-[#f9f9ff] border-[#c3c6d7] hover:bg-[#dee8ff]/40 text-[#111c2d]'
                }`}
                title={nearestPolice ? `Police: ${nearestPolice.name}` : 'Police'}
              >
                <span className="material-symbols-outlined text-base text-[#003ea8]">local_police</span>
                <span className="text-[11px] font-bold mt-0.5 leading-tight">Police</span>
                <span className="text-[9px] font-semibold text-[#003ea8] truncate w-full">
                  {nearestPolice ? nearestPolice.distance : '911'}
                </span>
              </button>

              {/* Closest Fire */}
              <button
                onClick={() => {
                  setSelectedCategory('fire');
                  if (nearestFire) handleSelectFacility(nearestFire);
                }}
                className={`p-1.5 rounded-lg border flex flex-col items-center justify-center text-center transition-all cursor-pointer ${
                  selectedCategory === 'fire'
                    ? 'bg-[#ffdad6] border-[#ba1a1a] text-[#93000a]'
                    : 'bg-[#f9f9ff] border-[#c3c6d7] hover:bg-[#ffdad6]/40 text-[#111c2d]'
                }`}
                title={nearestFire ? `Fire: ${nearestFire.name}` : 'Fire'}
              >
                <span className="material-symbols-outlined text-base text-[#ba1a1a]">local_fire_department</span>
                <span className="text-[11px] font-bold mt-0.5 leading-tight">Fire</span>
                <span className="text-[9px] font-semibold text-[#ba1a1a] truncate w-full">
                  {nearestFire ? nearestFire.distance : 'Rescue'}
                </span>
              </button>

              {/* Closest Ambulance */}
              <button
                onClick={() => {
                  setSelectedCategory('ambulance');
                  if (nearestAmbulance) handleSelectFacility(nearestAmbulance);
                }}
                className={`p-1.5 rounded-lg border flex flex-col items-center justify-center text-center transition-all cursor-pointer ${
                  selectedCategory === 'ambulance'
                    ? 'bg-[#bdffdc] border-[#006243] text-[#005137]'
                    : 'bg-[#f9f9ff] border-[#c3c6d7] hover:bg-[#bdffdc]/40 text-[#111c2d]'
                }`}
                title={nearestAmbulance ? `Ambulance: ${nearestAmbulance.name}` : 'Ambulance'}
              >
                <span className="material-symbols-outlined text-base text-[#006243]">ambulance</span>
                <span className="text-[11px] font-bold mt-0.5 leading-tight">Ambulance</span>
                <span className="text-[9px] font-semibold text-[#006243] truncate w-full">
                  {nearestAmbulance ? nearestAmbulance.distance : 'EMS'}
                </span>
              </button>
            </div>
          </div>

          {/* Search Input */}
          <div className="relative w-full">
            <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-[#434655]">
              search
            </span>
            <input
              type="text"
              placeholder="Search Narayana Malla Reddy, Suraram Police, ER, Fire, EMS..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 h-[42px] bg-white rounded-lg border border-[#c3c6d7] focus:border-[#004ac6] focus:ring-2 focus:ring-[#004ac6]/20 text-xs md:text-sm outline-none transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#737686] cursor-pointer"
              >
                <span className="material-symbols-outlined text-sm">close</span>
              </button>
            )}
          </div>

          {/* Filter Pills */}
          <div className="flex gap-2 overflow-x-auto pb-1 hide-scrollbar w-full">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`min-w-fit h-[36px] px-3.5 rounded-full font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer ${
                selectedCategory === 'all'
                  ? 'bg-[#004ac6] text-white shadow-xs'
                  : 'bg-white text-[#111c2d] border border-[#c3c6d7] hover:bg-[#d8e3fb]'
              }`}
            >
              All Services
            </button>

            <button
              onClick={() => setSelectedCategory('hospital')}
              className={`min-w-fit h-[36px] px-3.5 rounded-full font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer ${
                selectedCategory === 'hospital'
                  ? 'bg-[#004ac6] text-white shadow-xs'
                  : 'bg-white text-[#111c2d] border border-[#c3c6d7] hover:bg-[#d8e3fb]'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">local_hospital</span>
              Hospitals & ER
            </button>

            <button
              onClick={() => setSelectedCategory('police')}
              className={`min-w-fit h-[36px] px-3.5 rounded-full font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer ${
                selectedCategory === 'police'
                  ? 'bg-[#004ac6] text-white shadow-xs'
                  : 'bg-white text-[#111c2d] border border-[#c3c6d7] hover:bg-[#d8e3fb]'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">local_police</span>
              Police Stations
            </button>

            <button
              onClick={() => setSelectedCategory('fire')}
              className={`min-w-fit h-[36px] px-3.5 rounded-full font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer ${
                selectedCategory === 'fire'
                  ? 'bg-[#004ac6] text-white shadow-xs'
                  : 'bg-white text-[#111c2d] border border-[#c3c6d7] hover:bg-[#d8e3fb]'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">local_fire_department</span>
              Fire & Rescue
            </button>

            <button
              onClick={() => setSelectedCategory('ambulance')}
              className={`min-w-fit h-[36px] px-3.5 rounded-full font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer ${
                selectedCategory === 'ambulance'
                  ? 'bg-[#004ac6] text-white shadow-xs'
                  : 'bg-white text-[#111c2d] border border-[#c3c6d7] hover:bg-[#d8e3fb]'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">ambulance</span>
              Ambulance / EMS
            </button>
          </div>
        </div>

        {/* Facilities List */}
        <div className="flex-1 overflow-y-auto p-3 md:p-4 flex flex-col gap-3 bg-white">
          {facilities.map((fac) => {
            const isSelected = fac.id === selectedFacilityId;
            return (
              <div
                key={fac.id}
                onClick={() => handleSelectFacility(fac)}
                className={`bg-white rounded-xl p-3.5 border transition-all cursor-pointer flex flex-col gap-2.5 relative overflow-hidden group ${
                  isSelected
                    ? 'border-[#004ac6] ring-2 ring-[#004ac6]/20 shadow-md'
                    : 'border-[#c3c6d7] hover:border-[#004ac6]/50 shadow-xs'
                }`}
              >
                {/* Accent Bar */}
                <div
                  className={`absolute top-0 left-0 w-1.5 h-full transition-all ${
                    fac.category === 'hospital'
                      ? 'bg-[#004ac6]'
                      : fac.category === 'fire'
                      ? 'bg-[#ba1a1a]'
                      : fac.category === 'police'
                      ? 'bg-[#003ea8]'
                      : 'bg-[#006243]'
                  }`}
                ></div>

                <div className="pl-2">
                  <div className="flex items-center justify-between mb-1">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${getCategoryBadgeClass(
                        fac.category
                      )}`}
                    >
                      {fac.category === 'hospital'
                        ? 'Hospital & ER'
                        : fac.category === 'police'
                        ? 'Police Precinct'
                        : fac.category === 'fire'
                        ? 'Fire & Rescue'
                        : 'Ambulance / EMS'}
                    </span>
                    <span className="text-xs font-bold text-[#004ac6] flex items-center gap-1">
                      <span className="material-symbols-outlined text-xs">near_me</span>
                      <span>{fac.distance} away</span>
                    </span>
                  </div>

                  <h3 className="font-bold text-base text-[#111c2d]">{fac.name}</h3>
                  <p className="text-xs text-[#434655] mt-0.5">{fac.address}</p>
                </div>

                {/* Badges */}
                <div className="flex flex-wrap gap-1.5 pl-2">
                  {fac.badges.map((badge, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center gap-1 bg-[#f0f3ff] px-2 py-0.5 rounded text-[11px] font-semibold text-[#111c2d]"
                    >
                      <span className="material-symbols-outlined text-[12px] text-[#006243]">
                        check_circle
                      </span>
                      <span>{badge}</span>
                    </span>
                  ))}
                </div>

                {/* Actions */}
                <div className="flex gap-2 pt-2 border-t border-[#c3c6d7] pl-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleOpenDirections(fac);
                    }}
                    className="flex-1 h-[38px] bg-[#004ac6] text-white rounded-lg font-semibold text-xs flex items-center justify-center gap-1.5 hover:bg-[#003ea8] transition-colors shadow-xs cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-base">directions</span>
                    <span>Get Directions & Route</span>
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDialFacility(fac.phone);
                    }}
                    className="w-[38px] h-[38px] border border-[#c3c6d7] rounded-lg flex items-center justify-center text-[#111c2d] hover:bg-[#f0f3ff] transition-colors cursor-pointer"
                    title={`Call ${fac.phone}`}
                  >
                    <span className="material-symbols-outlined text-lg text-[#004ac6]">call</span>
                  </button>
                </div>
              </div>
            );
          })}

          {facilities.length === 0 && (
            <div className="text-center py-12 text-[#737686]">
              <span className="material-symbols-outlined text-4xl mb-2">search_off</span>
              <p className="text-sm font-semibold">No emergency facilities found matching your criteria.</p>
            </div>
          )}
        </div>
      </aside>

      {/* Interactive Leaflet Map Area */}
      <main className="flex-1 h-full relative bg-[#eef2f9] overflow-hidden flex flex-col">
        <div ref={mapContainerRef} className="w-full h-full z-0" />

        {/* Map Floating Controls */}
        <div className="absolute right-4 top-4 flex flex-col gap-2 z-10">
          <div className="bg-white rounded-xl shadow-lg border border-[#c3c6d7] flex flex-col overflow-hidden">
            <button
              onClick={() => {
                if (mapInstanceRef.current) mapInstanceRef.current.zoomIn();
              }}
              className="w-10 h-10 flex items-center justify-center hover:bg-[#f0f3ff] text-[#111c2d] border-b border-[#c3c6d7] cursor-pointer"
              title="Zoom In"
            >
              <span className="material-symbols-outlined text-lg">add</span>
            </button>
            <button
              onClick={() => {
                if (mapInstanceRef.current) mapInstanceRef.current.zoomOut();
              }}
              className="w-10 h-10 flex items-center justify-center hover:bg-[#f0f3ff] text-[#111c2d] cursor-pointer"
              title="Zoom Out"
            >
              <span className="material-symbols-outlined text-lg">remove</span>
            </button>
          </div>

          <button
            onClick={() => {
              if (mapInstanceRef.current) {
                mapInstanceRef.current.flyTo([userLocation.lat, userLocation.lng], 15);
              }
            }}
            className="w-10 h-10 bg-white rounded-xl shadow-lg border border-[#c3c6d7] flex items-center justify-center hover:bg-[#f0f3ff] text-[#004ac6] cursor-pointer"
            title="Center on My Live GPS Location"
          >
            <span className="material-symbols-outlined text-lg">my_location</span>
          </button>
        </div>

        {/* Live GPS Legend Floating Badge */}
        <div className="absolute left-4 top-4 bg-white/95 backdrop-blur-md px-3 py-2 rounded-xl shadow-lg border border-[#c3c6d7] z-10 hidden sm:flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5 font-semibold text-[#111c2d]">
            <span className="w-3 h-3 rounded-full bg-[#004ac6] animate-pulse"></span>
            <span>Your Live GPS: {userLocation.lat.toFixed(4)}, {userLocation.lng.toFixed(4)}</span>
          </div>
          <span className="text-[#c3c6d7]">|</span>
          <span className="text-[#434655]">{facilities.length} Emergency Hubs Nearby</span>
        </div>

        {/* Selected Facility Mobile Overlay */}
        {selectedFacility && (
          <div className="md:hidden absolute bottom-4 left-4 right-4 bg-white p-4 rounded-xl shadow-xl border border-[#c3c6d7] z-20 flex flex-col gap-2">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[10px] font-bold uppercase text-[#004ac6]">
                  {selectedFacility.category}
                </span>
                <h4 className="font-bold text-base text-[#111c2d]">{selectedFacility.name}</h4>
                <p className="text-xs text-[#434655]">{selectedFacility.address}</p>
              </div>
              <span className="text-xs font-bold text-[#004ac6]">{selectedFacility.distance}</span>
            </div>

            <div className="flex gap-2 mt-1">
              <button
                onClick={() => handleOpenDirections(selectedFacility)}
                className="flex-1 py-2 bg-[#004ac6] text-white rounded-lg font-semibold text-xs flex items-center justify-center gap-1 cursor-pointer"
              >
                <span className="material-symbols-outlined text-sm">directions</span>
                <span>Directions</span>
              </button>
              <button
                onClick={() => handleDialFacility(selectedFacility.phone)}
                className="w-10 h-10 border border-[#c3c6d7] rounded-lg flex items-center justify-center cursor-pointer text-[#004ac6]"
              >
                <span className="material-symbols-outlined text-sm">call</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Turn-by-Turn Directions Modal */}
      {directionsFacility && (
        <DirectionsModal
          facility={directionsFacility}
          userLocation={userLocation}
          onClose={() => setDirectionsFacility(null)}
          onCallFacility={handleDialFacility}
        />
      )}
    </div>
  );
};
