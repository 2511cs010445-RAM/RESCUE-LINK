import React, { useState, useEffect, useRef } from 'react';
import { NavigationTab } from '../types';

interface WelcomeOpeningViewProps {
  onEnterPortal: (tab: NavigationTab) => void;
  onTriggerSos: () => void;
  isSosActive: boolean;
}

export const WelcomeOpeningView: React.FC<WelcomeOpeningViewProps> = ({
  onEnterPortal,
  onTriggerSos,
  isSosActive,
}) => {
  const [selectedRole, setSelectedRole] = useState<'resident' | 'responder' | 'volunteer'>('resident');
  const [isDiagnosticRunning, setIsDiagnosticRunning] = useState(false);
  const [diagnosticProgress, setDiagnosticProgress] = useState(0);
  const [diagnosticComplete, setDiagnosticComplete] = useState(false);

  // Practice SOS state
  const [holdProgress, setHoldProgress] = useState(0);
  const [isHolding, setIsHolding] = useState(false);
  const [practiceSuccess, setPracticeSuccess] = useState(false);
  const [practiceStatusText, setPracticeStatusText] = useState('Press and hold for 3 seconds to test');
  const holdIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const circumference = 226; // 2 * pi * 36

  const startPracticeHold = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    setIsHolding(true);
    setPracticeSuccess(false);
    setPracticeStatusText('Testing emergency signal...');
    setHoldProgress(0);

    const startTime = Date.now();
    const duration = 3000;

    holdIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const percent = Math.min((elapsed / duration) * 100, 100);
      setHoldProgress(percent);

      if (percent >= 100) {
        if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);
        setPracticeSuccess(true);
        setIsHolding(false);
        setPracticeStatusText('Test complete. Your emergency button is ready.');
      }
    }, 40);
  };

  const cancelPracticeHold = () => {
    if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);
    if (!practiceSuccess) {
      setHoldProgress(0);
      setIsHolding(false);
      setPracticeStatusText('Press and hold for 3 seconds to test');
    }
  };

  const runDiagnostic = () => {
    setIsDiagnosticRunning(true);
    setDiagnosticComplete(false);
    setDiagnosticProgress(0);

    let current = 0;
    const interval = setInterval(() => {
      current += 20;
      if (current >= 100) {
        setDiagnosticProgress(100);
        clearInterval(interval);
        setIsDiagnosticRunning(false);
        setDiagnosticComplete(true);
      } else {
        setDiagnosticProgress(current);
      }
    }, 150);
  };

  useEffect(() => {
    return () => {
      if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);
    };
  }, []);

  const getRoleTitle = (role: 'resident' | 'responder' | 'volunteer') => {
    switch (role) {
      case 'resident':
        return 'Resident or Visitor';
      case 'responder':
        return 'First Responder';
      case 'volunteer':
        return 'Community Volunteer';
    }
  };

  return (
    <div className="flex-1 w-full bg-gradient-to-b from-slate-50 via-white to-slate-50 text-slate-900 flex flex-col justify-between pt-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 w-full flex flex-col gap-10">
        
        {/* Main Welcome Hero */}
        <div className="text-center max-w-3xl mx-auto flex flex-col items-center gap-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50/90 border border-blue-200/80 text-[#004ac6] text-xs font-bold tracking-wide shadow-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
            <span>RescueLink Active Safety Network • Hyderabad Node</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.15]">
            Instant Response When <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-[#004ac6] via-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Every Second Counts
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl font-medium">
            Connect directly with verified hospitals, trauma centers, police precincts, fire stations, and apex 108/100 emergency responders across Hyderabad.
          </p>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3.5 mt-2">
            <button
              onClick={() => onEnterPortal('dashboard')}
              className="px-7 py-3.5 bg-gradient-to-r from-[#004ac6] to-[#1d63e6] hover:from-[#003ea8] hover:to-[#1752c0] text-white font-bold text-sm rounded-xl transition-all shadow-lg shadow-blue-500/20 flex items-center gap-2 cursor-pointer active:scale-98"
            >
              <span>Explore Dashboard</span>
              <span className="material-symbols-outlined text-lg">arrow_forward</span>
            </button>

            <button
              onClick={() => {
                onTriggerSos();
                onEnterPortal('live-sos');
              }}
              className="px-7 py-3.5 bg-gradient-to-r from-[#bb0112] to-[#dc2626] hover:from-[#a00110] hover:to-[#b91c1c] text-white font-bold text-sm rounded-xl transition-all shadow-lg shadow-red-500/20 flex items-center gap-2 cursor-pointer active:scale-98"
            >
              <span className="material-symbols-outlined text-lg fill animate-pulse">emergency</span>
              <span>Trigger Emergency SOS</span>
            </button>
          </div>

          {/* RescueLink Core Telematics Ribbon */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full mt-4 pt-4 border-t border-slate-200/80">
            <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-xs flex flex-col items-center text-center">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Response Speed</span>
              <span className="text-sm font-extrabold text-[#004ac6] mt-0.5">&lt; 3 Sec Dispatch</span>
            </div>
            <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-xs flex flex-col items-center text-center">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Verified Network</span>
              <span className="text-sm font-extrabold text-emerald-600 mt-0.5">40+ Medical & Police</span>
            </div>
            <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-xs flex flex-col items-center text-center">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Direct Dial</span>
              <span className="text-sm font-extrabold text-indigo-600 mt-0.5">100 • 108 • 101</span>
            </div>
            <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-xs flex flex-col items-center text-center">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">GPS Precision</span>
              <span className="text-sm font-extrabold text-red-600 mt-0.5">Live Beacon Link</span>
            </div>
          </div>
        </div>

        {/* 3 Interactive Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
          
          {/* Card 1: Select User Role */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-extrabold text-[#004ac6] uppercase tracking-wider bg-blue-50 px-2 py-0.5 rounded-md">Step 1</span>
                <span className="material-symbols-outlined text-slate-400">person</span>
              </div>

              <h2 className="text-lg font-bold text-slate-900 mb-1">Choose who you are</h2>
              <p className="text-xs text-slate-500 mb-5">
                Select your role to personalize RescueLink dispatch tools and workflows.
              </p>

              {/* Options */}
              <div className="space-y-2.5">
                <button
                  type="button"
                  onClick={() => setSelectedRole('resident')}
                  className={`w-full p-3.5 rounded-xl border text-left transition-all flex items-start gap-3 cursor-pointer ${
                    selectedRole === 'resident'
                      ? 'bg-blue-50/80 border-[#004ac6] text-[#004ac6] shadow-xs'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <span className="material-symbols-outlined text-xl mt-0.5">shield</span>
                  <div>
                    <h3 className="font-bold text-xs sm:text-sm text-slate-900">Resident or Visitor</h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Need emergency help, report hazards, or find nearby care
                    </p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedRole('responder')}
                  className={`w-full p-3.5 rounded-xl border text-left transition-all flex items-start gap-3 cursor-pointer ${
                    selectedRole === 'responder'
                      ? 'bg-blue-50/80 border-[#004ac6] text-[#004ac6] shadow-xs'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <span className="material-symbols-outlined text-xl mt-0.5">local_police</span>
                  <div>
                    <h3 className="font-bold text-xs sm:text-sm text-slate-900">First Responder</h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Police, fire, and medical squads responding to incidents
                    </p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedRole('volunteer')}
                  className={`w-full p-3.5 rounded-xl border text-left transition-all flex items-start gap-3 cursor-pointer ${
                    selectedRole === 'volunteer'
                      ? 'bg-blue-50/80 border-[#004ac6] text-[#004ac6] shadow-xs'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <span className="material-symbols-outlined text-xl mt-0.5">volunteer_activism</span>
                  <div>
                    <h3 className="font-bold text-xs sm:text-sm text-slate-900">Community Volunteer</h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Help neighbors, monitor safe corridors, and support relief
                    </p>
                  </div>
                </button>
              </div>
            </div>

            <button
              onClick={() => onEnterPortal('dashboard')}
              className="mt-6 w-full py-3 bg-slate-100 hover:bg-slate-200 border border-slate-300/80 rounded-xl font-bold text-xs text-[#004ac6] transition-colors cursor-pointer flex items-center justify-center gap-1"
            >
              <span>Continue as {getRoleTitle(selectedRole)}</span>
              <span className="material-symbols-outlined text-sm">arrow_forward</span>
            </button>
          </div>

          {/* Card 2: Device & Connection Test */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-extrabold text-[#004ac6] uppercase tracking-wider bg-blue-50 px-2 py-0.5 rounded-md">Step 2</span>
                <span className="material-symbols-outlined text-slate-400">sensors</span>
              </div>

              <h2 className="text-lg font-bold text-slate-900 mb-1">Check your connection</h2>
              <p className="text-xs text-slate-500 mb-5">
                Verify that your device GPS telematics and emergency networks are primed.
              </p>

              {/* Status List */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <span className="material-symbols-outlined text-emerald-600 text-lg">
                      location_on
                    </span>
                    <span className="text-xs font-semibold text-slate-800">GPS Location Telematics</span>
                  </div>
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    {diagnosticComplete || diagnosticProgress > 30 ? 'Locked (Suraram)' : 'Active'}
                  </span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <span className="material-symbols-outlined text-[#004ac6] text-lg">
                      wifi
                    </span>
                    <span className="text-xs font-semibold text-slate-800">Internet & Cloud Sync</span>
                  </div>
                  <span className="text-xs font-bold text-[#004ac6]">
                    {diagnosticComplete || diagnosticProgress > 60 ? 'Ultra-Fast (9ms)' : 'Online'}
                  </span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <span className="material-symbols-outlined text-[#bb0112] text-lg">
                      call
                    </span>
                    <span className="text-xs font-semibold text-slate-800">108 / 100 Apex Lines</span>
                  </div>
                  <span className="text-xs font-bold text-emerald-600">
                    {diagnosticComplete || diagnosticProgress > 90 ? 'Direct Standby' : 'Available 24/7'}
                  </span>
                </div>
              </div>

              {/* Progress Bar */}
              {isDiagnosticRunning && (
                <div className="mt-4">
                  <div className="flex justify-between text-xs mb-1 font-bold text-[#004ac6]">
                    <span>Scanning RescueLink telemetry...</span>
                    <span>{diagnosticProgress}%</span>
                  </div>
                  <div className="w-full bg-blue-100 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-blue-600 to-indigo-600 h-1.5 rounded-full transition-all duration-150"
                      style={{ width: `${diagnosticProgress}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={runDiagnostic}
              disabled={isDiagnosticRunning}
              className={`mt-6 w-full py-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer ${
                diagnosticComplete
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-300'
                  : 'bg-gradient-to-r from-[#004ac6] to-[#1d63e6] hover:from-[#003ea8] hover:to-[#1752c0] text-white shadow-md shadow-blue-500/15'
              }`}
            >
              <span className="material-symbols-outlined text-base">
                {diagnosticComplete ? 'check_circle' : 'refresh'}
              </span>
              <span>
                {isDiagnosticRunning
                  ? 'Diagnosing Telemetry...'
                  : diagnosticComplete
                  ? 'All Systems Ready (Test Again)'
                  : 'Test Emergency Connectivity'}
              </span>
            </button>
          </div>

          {/* Card 3: Safe Practice SOS Button */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-extrabold text-[#bb0112] uppercase tracking-wider bg-red-50 px-2 py-0.5 rounded-md">Step 3</span>
                <span className="material-symbols-outlined text-slate-400">touch_app</span>
              </div>

              <h2 className="text-lg font-bold text-slate-900 mb-1">Try the SOS button</h2>
              <p className="text-xs text-slate-500 mb-4">
                Simulate triggering an emergency beacon safely without dispatching real squads.
              </p>

              {/* Interactive Practice Button */}
              <div className="flex flex-col items-center justify-center my-3">
                <button
                  onMouseDown={startPracticeHold}
                  onMouseUp={cancelPracticeHold}
                  onMouseLeave={cancelPracticeHold}
                  onTouchStart={startPracticeHold}
                  onTouchEnd={cancelPracticeHold}
                  className={`w-28 h-28 rounded-full flex flex-col items-center justify-center shadow-lg relative cursor-pointer select-none transition-all ${
                    practiceSuccess
                      ? 'bg-gradient-to-br from-emerald-600 to-teal-700 text-white shadow-emerald-500/30'
                      : 'bg-gradient-to-br from-[#bb0112] via-red-600 to-rose-700 text-white shadow-red-500/30 active:scale-95'
                  }`}
                >
                  <span className="material-symbols-outlined text-3xl mb-0.5 fill">
                    {practiceSuccess ? 'check' : 'sos'}
                  </span>
                  <span className="text-[11px] font-bold tracking-tight">
                    {practiceSuccess ? 'Ready' : 'Hold 3s'}
                  </span>

                  {/* SVG Progress Ring */}
                  <svg
                    className={`absolute inset-0 w-full h-full -rotate-90 ${
                      isHolding || practiceSuccess ? 'block' : 'hidden'
                    }`}
                    viewBox="0 0 80 80"
                  >
                    <circle
                      cx="40"
                      cy="40"
                      r="36"
                      fill="none"
                      stroke="rgba(255,255,255,0.3)"
                      strokeWidth="5"
                    />
                    <circle
                      cx="40"
                      cy="40"
                      r="36"
                      fill="none"
                      stroke="#ffffff"
                      strokeWidth="5"
                      strokeDasharray={circumference}
                      strokeDashoffset={
                        practiceSuccess
                          ? 0
                          : circumference - (holdProgress / 100) * circumference
                      }
                      className="transition-all duration-75"
                    />
                  </svg>
                </button>

                <span className="text-xs text-slate-600 mt-3 min-h-[18px] text-center font-semibold">
                  {practiceStatusText}
                </span>
              </div>
            </div>

            <button
              onClick={() => onEnterPortal('locate')}
              className="w-full py-3 bg-slate-100 hover:bg-slate-200 border border-slate-300/80 rounded-xl font-bold text-xs text-slate-800 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span className="material-symbols-outlined text-base text-[#004ac6]">near_me</span>
              <span>Find Nearest Hospital, Police & Fire</span>
            </button>
          </div>
        </div>

        {/* Quick Links to Key Sections */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 pt-2">
          <div
            onClick={() => onEnterPortal('dashboard')}
            className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-[#004ac6] hover:shadow-md transition-all cursor-pointer group flex items-center gap-3.5"
          >
            <div className="w-11 h-11 rounded-xl bg-blue-50 text-[#004ac6] flex items-center justify-center group-hover:scale-110 transition-transform shrink-0 shadow-xs">
              <span className="material-symbols-outlined">dashboard</span>
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-900">Dashboard</h4>
              <p className="text-xs text-slate-500">Live community alerts & stats</p>
            </div>
          </div>

          <div
            onClick={() => onEnterPortal('locate')}
            className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-emerald-600 hover:shadow-md transition-all cursor-pointer group flex items-center gap-3.5"
          >
            <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition-transform shrink-0 shadow-xs">
              <span className="material-symbols-outlined">near_me</span>
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-900">Nearby Services</h4>
              <p className="text-xs text-slate-500">40+ Hospitals, Police & Fire</p>
            </div>
          </div>

          <div
            onClick={() => onEnterPortal('incidents')}
            className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-amber-600 hover:shadow-md transition-all cursor-pointer group flex items-center gap-3.5"
          >
            <div className="w-11 h-11 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center group-hover:scale-110 transition-transform shrink-0 shadow-xs">
              <span className="material-symbols-outlined">report</span>
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-900">Report Incident</h4>
              <p className="text-xs text-slate-500">Share road hazard or outage</p>
            </div>
          </div>

          <div
            onClick={() => onEnterPortal('live-sos')}
            className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-red-600 hover:shadow-md transition-all cursor-pointer group flex items-center gap-3.5"
          >
            <div className="w-11 h-11 rounded-xl bg-red-50 text-[#bb0112] flex items-center justify-center group-hover:scale-110 transition-transform shrink-0 shadow-xs">
              <span className="material-symbols-outlined fill">emergency</span>
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-900">Emergency SOS</h4>
              <p className="text-xs text-slate-500">Instant GPS beacon dispatch</p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
