import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#cfdaf2] mt-auto w-full py-4 px-6 md:px-12 flex flex-col md:flex-row justify-between items-center gap-4 border-t border-[#c3c6d7] text-xs text-[#111c2d]">
      <div className="font-medium text-center md:text-left">
        © 2026 Emergency Services Public Safety Portal. All rights reserved.
      </div>
      <div className="flex flex-wrap justify-center gap-4">
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            alert('Privacy Policy: All location data is strictly encrypted and used only for emergency dispatch operations.');
          }}
          className="text-[#434655] hover:text-[#111c2d] hover:underline"
        >
          Privacy Policy
        </a>
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            alert('Terms of Service: Emergency Public Safety Portal agreement for official dispatch access.');
          }}
          className="text-[#434655] hover:text-[#111c2d] hover:underline"
        >
          Terms of Service
        </a>
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            alert('Contact Dispatch Hotline: 1-800-555-RESCUE');
          }}
          className="text-[#434655] hover:text-[#111c2d] hover:underline"
        >
          Contact Dispatch
        </a>
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            alert('Accessibility Features: High contrast UI, screen reader support, keyboard navigation enabled.');
          }}
          className="text-[#434655] hover:text-[#111c2d] hover:underline"
        >
          Accessibility
        </a>
      </div>
    </footer>
  );
};
