import React, { useState, useEffect, useRef } from 'react';
import L from 'leaflet';
import { EmergencyContact } from '../types';
import { broadcastTestPing, reverseGeocode } from '../services/api';

interface LiveSosViewProps {
  contacts: EmergencyContact[];
  onCancelSos: () => void;
  onAddContact?: (name: string, role: string, phone: string) => void;
}

export const LiveSosView: React.FC<LiveSosViewProps> = ({
  contacts,
  onCancelSos,
  onAddContact,
}) => {
  const [timeLeft, setTimeLeft] = useState(45); // Countdown 45s
  const [isSharingActive, setIsSharingActive] = useState(true);
  const [showAddContactModal, setShowAddContactModal] = useState(false);
  const [newContactName, setNewContactName] = useState('');
  const [newContactRole, setNewContactRole] = useState('Emergency Contact');
  const [newContactPhone, setNewContactPhone] = useState('');
  const [isPinging, setIsPinging] = useState(false);
  const [pingFeedback, setPingFeedback] = useState('');

  const [liveCoords, setLiveCoords] = useState<{ lat: number; lng: number; address: string; accuracy: number }>({
    lat: 47.6062,
    lng: -122.3321,
    address: '47°36\'22.1"N 122°19\'55.4"W (Downtown Sector)',
    accuracy: 3,
  });

  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const sosMarkerRef = useRef<L.Marker | null>(null);

  // Acquire real GPS position
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          const { latitude, longitude, accuracy } = pos.coords;
          let addr = `${latitude.toFixed(4)}°N, ${longitude.toFixed(4)}°W`;
          try {
            const rev = await reverseGeocode(latitude, longitude);
            if (rev && rev.address) {
              addr = rev.shortAddress || rev.address;
            }
          } catch {}

          setLiveCoords({
            lat: latitude,
            lng: longitude,
            address: addr,
            accuracy: Math.round(accuracy),
          });

          if (mapInstanceRef.current) {
            mapInstanceRef.current.setView([latitude, longitude], 15);
          }
        },
        (err) => {
          console.warn('Live SOS GPS notice:', err.message);
        },
        { enableHighAccuracy: true }
      );
    }
  }, []);

  // Leaflet map setup for SOS View
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        zoomControl: false,
        attributionControl: false,
      }).setView([liveCoords.lat, liveCoords.lng], 15);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
      }).addTo(map);

      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;
    if (!map) return;

    if (sosMarkerRef.current) {
      map.removeLayer(sosMarkerRef.current);
    }

    const sosIcon = L.divIcon({
      className: 'sos-gps-beacon',
      html: `
        <div style="position: relative; width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
          <div style="position: absolute; width: 60px; height: 60px; background-color: rgba(186, 26, 26, 0.35); border-radius: 50%; animation: pulse-ring 1.8s infinite;"></div>
          <div style="width: 28px; height: 28px; background-color: #ba1a1a; border: 3px solid #ffffff; border-radius: 50%; box-shadow: 0 4px 12px rgba(186, 26, 26, 0.6); display: flex; align-items: center; justify-content: center; color: white;">
            <span class="material-symbols-outlined" style="font-size: 16px; font-variation-settings: 'FILL' 1;">warning</span>
          </div>
        </div>
      `,
      iconSize: [60, 60],
      iconAnchor: [30, 30],
    });

    const marker = L.marker([liveCoords.lat, liveCoords.lng], { icon: sosIcon })
      .bindPopup(`
        <div style="font-family: sans-serif; padding: 2px;">
          <b style="color: #ba1a1a; font-size: 13px;">ACTIVE SOS DISTRESS BEACON</b>
          <div style="font-size: 11px; color: #111c2d; margin-top: 2px;">${liveCoords.address}</div>
          <div style="font-size: 10px; color: #006243; font-weight: bold; margin-top: 4px;">DISPATCH EN ROUTE (ETA ~3 MIN)</div>
        </div>
      `)
      .addTo(map)
      .openPopup();

    sosMarkerRef.current = marker;

    setTimeout(() => {
      map.invalidateSize();
    }, 150);
  }, [liveCoords]);

  const handleTestBroadcast = async () => {
    setIsPinging(true);
    try {
      const res = await broadcastTestPing();
      setPingFeedback(res.message);
      setTimeout(() => setPingFeedback(''), 4000);
    } catch {
      setPingFeedback('Ping dispatched to contacts.');
      setTimeout(() => setPingFeedback(''), 4000);
    } finally {
      setIsPinging(false);
    }
  };

  // Ticking countdown
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `0${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleCreateContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContactName.trim()) return;
    if (onAddContact) {
      onAddContact(newContactName, newContactRole, newContactPhone);
    }
    setNewContactName('');
    setNewContactPhone('');
    setShowAddContactModal(false);
  };

  return (
    <div className="flex-1 flex flex-col h-full relative z-0 min-h-[calc(100vh-64px)] pt-16 lg:pl-64">
      {/* SOS Active Status Banner */}
      <div className="bg-[#ba1a1a] text-white w-full py-3 px-4 md:px-8 flex flex-col sm:flex-row justify-between items-center gap-4 shadow-sm z-30 shrink-0">
        <div className="flex items-center gap-3">
          <span className="material-symbols-outlined text-2xl animate-pulse fill">warning</span>
          <div>
            <h2 className="text-lg font-bold tracking-tight leading-tight">SOS ACTIVE</h2>
            <p className="text-xs opacity-90">Transmitting live GPS telemetry to emergency dispatchers and emergency contacts.</p>
          </div>
        </div>

        <div className="flex items-center gap-4 w-full sm:w-auto">
          <div className="flex items-center gap-2 bg-black/20 px-3.5 py-1.5 rounded-full text-sm font-bold tracking-wider">
            <span className="material-symbols-outlined text-sm">timer</span>
            <span>{formatTimer(timeLeft)}</span>
          </div>

          <button
            onClick={onCancelSos}
            className="bg-white text-[#ba1a1a] font-bold text-sm px-6 py-2 rounded-full hover:bg-[#ffdad6] transition-colors h-10 flex-1 sm:flex-none border-2 border-[#ba1a1a] shadow-sm cursor-pointer"
          >
            CANCEL SOS
          </button>
        </div>
      </div>

      {/* Content Canvas */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
        {/* Interactive Leaflet Map Area */}
        <div className="flex-1 relative bg-[#cfdaf2] overflow-hidden min-h-[420px] lg:min-h-0 z-10">
          <div ref={mapContainerRef} className="w-full h-full z-0" />

          {/* Location Details Overlay Card */}
          <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-md p-3.5 rounded-xl shadow-lg border border-[#c3c6d7] max-w-xs z-10">
            <p className="text-[10px] font-bold text-[#ba1a1a] mb-0.5 uppercase tracking-wider flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#ba1a1a] animate-ping"></span>
              Live Transmitting Location
            </p>
            <p className="text-sm font-bold text-[#111c2d] leading-snug">{liveCoords.address}</p>
            <div className="flex items-center gap-2 text-xs text-[#434655] mt-1.5">
              <span className="w-2 h-2 rounded-full bg-[#006243]"></span>
              <span>GPS Precision: ±{liveCoords.accuracy}m</span>
            </div>
          </div>

          {/* Map Floating Controls */}
          <div className="absolute right-4 bottom-6 flex flex-col gap-2 z-10">
            <button
              onClick={() => {
                if (mapInstanceRef.current) mapInstanceRef.current.zoomIn();
              }}
              className="bg-white text-[#111c2d] rounded-full shadow-md hover:bg-[#f0f3ff] transition-colors h-11 w-11 flex items-center justify-center border border-[#c3c6d7] cursor-pointer"
              title="Zoom In"
            >
              <span className="material-symbols-outlined">add</span>
            </button>
            <button
              onClick={() => {
                if (mapInstanceRef.current) mapInstanceRef.current.zoomOut();
              }}
              className="bg-white text-[#111c2d] rounded-full shadow-md hover:bg-[#f0f3ff] transition-colors h-11 w-11 flex items-center justify-center border border-[#c3c6d7] cursor-pointer"
              title="Zoom Out"
            >
              <span className="material-symbols-outlined">remove</span>
            </button>
            <button
              onClick={() => {
                if (mapInstanceRef.current) {
                  mapInstanceRef.current.flyTo([liveCoords.lat, liveCoords.lng], 16);
                }
              }}
              className="bg-white text-[#ba1a1a] rounded-full shadow-md hover:bg-[#ffdad6] transition-colors h-11 w-11 flex items-center justify-center border border-[#c3c6d7] cursor-pointer"
              title="Center on Distress Beacon"
            >
              <span className="material-symbols-outlined">my_location</span>
            </button>
          </div>
        </div>

        {/* Sidebar / Details Panel */}
        <div className="w-full lg:w-96 bg-[#f9f9ff] border-l border-[#c3c6d7] flex flex-col shrink-0 overflow-y-auto z-20 shadow-xl">
          {/* Sharing Status Box */}
          <div className="p-5 border-b border-[#c3c6d7]">
            <h3 className="text-base font-bold text-[#111c2d] mb-3">Live Telemetry Status</h3>

            <label className="flex items-center justify-between p-3.5 bg-[#e7eeff] rounded-xl cursor-pointer hover:bg-[#dee8ff] transition-colors border border-[#c3c6d7]">
              <div className="flex items-center gap-3">
                <span className="material-symbols-outlined text-[#004ac6] text-2xl fill">
                  share_location
                </span>
                <div>
                  <span className="block font-semibold text-sm text-[#111c2d]">
                    Live Coordinate Sharing
                  </span>
                  <span className="block text-xs text-[#434655] mt-0.5">
                    {isSharingActive ? 'Active - Updating in real-time' : 'Paused by user'}
                  </span>
                </div>
              </div>

              <div
                onClick={() => setIsSharingActive(!isSharingActive)}
                className={`w-12 h-7 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
                  isSharingActive ? 'bg-[#004ac6]' : 'bg-[#737686]'
                }`}
              >
                <div
                  className={`bg-white w-5 h-5 rounded-full shadow-md transform transition-transform ${
                    isSharingActive ? 'translate-x-5' : 'translate-x-0'
                  }`}
                ></div>
              </div>
            </label>
          </div>

          {/* Notified Contacts List */}
          <div className="p-5 flex-1">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-bold text-[#111c2d]">Notified Contacts</h3>
              <span className="bg-[#ffdad6] text-[#93000a] text-xs font-bold px-2.5 py-0.5 rounded-full border border-[#ffb4ab]">
                {contacts.length} Alerted
              </span>
            </div>

            <ul className="space-y-2.5">
              {contacts.map((contact) => (
                <li
                  key={contact.id}
                  className="flex items-start gap-3 p-3 bg-white rounded-xl border border-[#c3c6d7] shadow-xs relative overflow-hidden"
                >
                  {/* Status Bar Indicator */}
                  <div
                    className={`absolute left-0 top-0 bottom-0 w-1 ${
                      contact.status === 'delivered' || contact.status === 'received'
                        ? 'bg-[#006243]'
                        : 'bg-[#737686]'
                    }`}
                  ></div>

                  <div className="w-9 h-9 rounded-full bg-[#d8e3fb] flex items-center justify-center shrink-0">
                    <span className="material-symbols-outlined text-[#434655] text-lg">person</span>
                  </div>

                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-sm text-[#111c2d] truncate">{contact.name}</h4>
                    <p className="text-xs text-[#434655]">{contact.role}</p>

                    <div
                      className={`inline-flex items-center gap-1 mt-1 px-2 py-0.5 rounded text-[11px] font-semibold ${
                        contact.status === 'delivered' || contact.status === 'received'
                          ? 'bg-[#bdffdc] text-[#005137]'
                          : 'bg-[#f0f3ff] text-[#434655]'
                      }`}
                    >
                      <span className="material-symbols-outlined text-xs">
                        {contact.status === 'delivered' || contact.status === 'received'
                          ? 'check'
                          : 'sync'}
                      </span>
                      <span>{contact.statusMessage}</span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>

            {/* Ping feedback message */}
            {pingFeedback && (
              <div className="mt-3 p-2.5 bg-[#85f8c4] text-[#002114] rounded-lg text-xs font-semibold flex items-center gap-1.5 border border-[#006243]">
                <span className="material-symbols-outlined text-sm">check_circle</span>
                <span>{pingFeedback}</span>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex flex-col gap-2 mt-4">
              <button
                onClick={() => setShowAddContactModal(true)}
                className="w-full border border-dashed border-[#004ac6] text-[#004ac6] py-2.5 px-4 rounded-xl font-semibold text-xs hover:bg-[#d8e3fb]/40 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span className="material-symbols-outlined text-sm">add</span>
                <span>Add Emergency Contact</span>
              </button>

              <button
                onClick={handleTestBroadcast}
                disabled={isPinging}
                className="w-full bg-[#f0f3ff] text-[#004ac6] hover:bg-[#dee8ff] py-2 px-4 rounded-xl font-semibold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer border border-[#c3c6d7]"
              >
                <span className="material-symbols-outlined text-sm">cell_tower</span>
                <span>{isPinging ? 'Broadcasting test ping...' : 'Send Live Test Ping to All'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Add Contact Modal */}
      {showAddContactModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl border border-[#c3c6d7] animate-fadeIn">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-lg text-[#111c2d]">Add Emergency Contact</h3>
              <button
                onClick={() => setShowAddContactModal(false)}
                className="text-[#434655] hover:text-[#111c2d]"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleCreateContact} className="flex flex-col gap-4">
              <div>
                <label className="block text-xs font-semibold text-[#434655] mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={newContactName}
                  onChange={(e) => setNewContactName(e.target.value)}
                  placeholder="e.g. Dr. Alex Morgan"
                  className="w-full bg-[#f0f3ff] border border-[#c3c6d7] rounded-lg px-3 py-2 text-sm text-[#111c2d] focus:outline-none focus:border-[#004ac6]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#434655] mb-1">Role / Relationship</label>
                <input
                  type="text"
                  value={newContactRole}
                  onChange={(e) => setNewContactRole(e.target.value)}
                  placeholder="e.g. Primary Physician, Spouse"
                  className="w-full bg-[#f0f3ff] border border-[#c3c6d7] rounded-lg px-3 py-2 text-sm text-[#111c2d] focus:outline-none focus:border-[#004ac6]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#434655] mb-1">Phone Number</label>
                <input
                  type="tel"
                  value={newContactPhone}
                  onChange={(e) => setNewContactPhone(e.target.value)}
                  placeholder="e.g. +1 (555) 345-6789"
                  className="w-full bg-[#f0f3ff] border border-[#c3c6d7] rounded-lg px-3 py-2 text-sm text-[#111c2d] focus:outline-none focus:border-[#004ac6]"
                />
              </div>

              <div className="flex justify-end gap-3 mt-4">
                <button
                  type="button"
                  onClick={() => setShowAddContactModal(false)}
                  className="px-4 py-2 rounded-lg text-sm font-semibold text-[#434655] hover:bg-[#f0f3ff]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-sm font-semibold bg-[#004ac6] text-white hover:bg-[#003ea8] shadow-xs"
                >
                  Save & Notify
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
