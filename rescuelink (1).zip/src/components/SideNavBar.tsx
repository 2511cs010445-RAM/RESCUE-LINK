import React from 'react';
import { NavigationTab } from '../types';

interface SideNavBarProps {
  currentTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  onNewIncident: () => void;
  isSosActive?: boolean;
}

export const SideNavBar: React.FC<SideNavBarProps> = ({
  currentTab,
  onSelectTab,
  onNewIncident,
  isSosActive = false,
}) => {
  return (
    <nav className="hidden lg:flex flex-col h-screen pt-20 pb-6 bg-slate-50/90 backdrop-blur-md border-r border-slate-200/90 w-64 shrink-0 shadow-xs z-40 fixed left-0 top-0">
      {/* Dispatch Hub Header */}
      <div className="px-5 mb-5 flex flex-col items-start">
        <div className="w-full p-3 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white flex items-center justify-center shadow-xs">
            <span className="material-symbols-outlined text-xl">shield_person</span>
          </div>
          <div>
            <h2 className="font-bold text-sm text-slate-800 leading-tight">RescueLink Hub</h2>
            <span className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1 mt-0.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
              Online Telematics
            </span>
          </div>
        </div>
      </div>

      {/* New Incident Action */}
      <div className="px-4 mb-4">
        <button
          onClick={onNewIncident}
          className="w-full bg-gradient-to-r from-[#004ac6] to-[#1d63e6] text-white font-bold text-xs py-3 px-4 rounded-xl hover:from-[#003ea8] hover:to-[#1752c0] transition-all shadow-md shadow-blue-500/15 flex items-center justify-center gap-2 h-11 active:scale-98 cursor-pointer"
        >
          <span className="material-symbols-outlined text-lg fill">add_circle</span>
          <span>Report New Incident</span>
        </button>
      </div>

      {/* Navigation Links */}
      <ul className="flex-1 overflow-y-auto px-3 space-y-1.5 font-medium">
        <li>
          <button
            onClick={() => onSelectTab('dashboard')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-semibold text-xs transition-all h-11 cursor-pointer ${
              currentTab === 'dashboard'
                ? 'bg-[#004ac6] text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-200/60 hover:text-slate-900'
            }`}
          >
            <span className="material-symbols-outlined text-lg">dashboard</span>
            <span>Dashboard Overview</span>
          </button>
        </li>

        <li>
          <button
            onClick={() => onSelectTab('live-sos')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-bold text-xs transition-all h-11 relative cursor-pointer ${
              currentTab === 'live-sos'
                ? 'bg-[#bb0112] text-white shadow-sm'
                : 'text-[#bb0112] bg-red-50/70 hover:bg-red-100/70'
            }`}
          >
            <span className="material-symbols-outlined text-lg fill">emergency</span>
            <span>Live SOS Beacon</span>
            {isSosActive && (
              <span className="ml-auto w-2.5 h-2.5 bg-white rounded-full animate-ping"></span>
            )}
          </button>
        </li>

        <li>
          <button
            onClick={() => onSelectTab('incidents')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-semibold text-xs transition-all h-11 cursor-pointer ${
              currentTab === 'incidents'
                ? 'bg-[#004ac6] text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-200/60 hover:text-slate-900'
            }`}
          >
            <span className="material-symbols-outlined text-lg">report_problem</span>
            <span>Incident Feed</span>
          </button>
        </li>

        <li>
          <button
            onClick={() => onSelectTab('locate')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-semibold text-xs transition-all h-11 cursor-pointer ${
              currentTab === 'locate'
                ? 'bg-[#004ac6] text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-200/60 hover:text-slate-900'
            }`}
          >
            <span className="material-symbols-outlined text-lg">near_me</span>
            <span>Locate Map Explorer</span>
          </button>
        </li>
      </ul>

      {/* Footer Nav */}
      <div className="px-4 mt-auto border-t border-slate-200 pt-3 space-y-1">
        <div className="bg-slate-100/90 rounded-xl p-3 mb-2 text-slate-600">
          <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 mb-1">
            <span>Hyderabad Node</span>
            <span className="text-emerald-600">Active</span>
          </div>
          <p className="text-[10px] text-slate-500">Connected to Dial 100, 108 & 101 emergency telematics.</p>
        </div>
      </div>
    </nav>
  );
};
