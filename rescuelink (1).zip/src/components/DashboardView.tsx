import React, { useState, useRef, useEffect } from 'react';
import { IncidentFeedItem, NavigationTab, SystemAdvisory, NearbyFacility, FacilityCategory } from '../types';
import { DirectionsModal } from './DirectionsModal';

interface DashboardViewProps {
  advisory: SystemAdvisory;
  incidents: IncidentFeedItem[];
  facilities?: NearbyFacility[];
  onSelectTab: (tab: NavigationTab) => void;
  onTriggerSos: () => void;
  isSosActive: boolean;
  onQuickCategoryClick: (category: string) => void;
  onSelectFacilityCategory?: (category: FacilityCategory) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  advisory,
  incidents,
  facilities = [],
  onSelectTab,
  onTriggerSos,
  isSosActive,
  onQuickCategoryClick,
  onSelectFacilityCategory,
}) => {
  const [holdProgress, setHoldProgress] = useState(0); // 0 to 100
  const [isHolding, setIsHolding] = useState(false);
  const [sosStatusText, setSosStatusText] = useState('');
  const [feedFilter, setFeedFilter] = useState<'all' | 'accident' | 'hazard' | 'medical'>('all');
  const [selectedDirectionFacility, setSelectedDirectionFacility] = useState<NearbyFacility | null>(null);

  const holdIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const circumference = 289; // 2 * pi * 46
  const strokeOffset = circumference - (holdProgress / 100) * circumference;

  const startHold = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    if (isSosActive) return;

    setIsHolding(true);
    setSosStatusText('Hold for 3 seconds to confirm...');
    setHoldProgress(0);

    const startTime = Date.now();
    const duration = 3000;

    holdIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progressPercent = Math.min((elapsed / duration) * 100, 100);
      setHoldProgress(progressPercent);

      if (progressPercent >= 100) {
        if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);
        onTriggerSos();
        setSosStatusText('DISPATCHED. Help is on the way.');
        setIsHolding(false);
      }
    }, 40);
  };

  const cancelHold = () => {
    if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);
    if (!isSosActive) {
      setHoldProgress(0);
      setIsHolding(false);
      setSosStatusText('');
    }
  };

  useEffect(() => {
    return () => {
      if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);
    };
  }, []);

  const filteredIncidents = incidents.filter((item) => {
    if (feedFilter === 'all') return true;
    return item.category === feedFilter;
  });

  // Calculate nearest of each of the 4 core emergency services
  const nearestHospital = facilities.find((f) => f.category === 'hospital');
  const nearestPolice = facilities.find((f) => f.category === 'police');
  const nearestFire = facilities.find((f) => f.category === 'fire');
  const nearestAmbulance = facilities.find((f) => f.category === 'ambulance');

  const handleNavigateToCategory = (cat: FacilityCategory) => {
    if (onSelectFacilityCategory) {
      onSelectFacilityCategory(cat);
    }
    onSelectTab('locate');
  };

  return (
    <div className="flex-grow pt-20 pb-12 px-4 md:px-12 max-w-7xl mx-auto w-full flex flex-col gap-6">
      {/* System Alert Banner */}
      {advisory.active && (
        <div className="w-full bg-[#ffdad6] text-[#93000a] p-4 rounded-xl flex items-start justify-between gap-4 border border-[#ffb4ab] shadow-xs">
          <div className="flex items-start gap-3">
            <span className="material-symbols-outlined text-[#ba1a1a] mt-0.5 text-2xl">warning</span>
            <div>
              <h4 className="font-semibold text-lg text-[#ba1a1a] mb-1">{advisory.title}</h4>
              <p className="text-sm text-[#434655] font-normal leading-relaxed">{advisory.description}</p>
            </div>
          </div>
          <button
            onClick={() => onSelectTab('incidents')}
            className="text-xs font-bold text-[#ba1a1a] underline hover:opacity-80 shrink-0 mt-1 cursor-pointer"
          >
            Report Hazard
          </button>
        </div>
      )}

      {/* Dashboard Header & Safe Status Indicator */}
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl md:text-5xl font-bold text-[#111c2d] tracking-tight mb-2">
            Emergency Dashboard
          </h1>
          <p className="text-base md:text-lg text-[#434655]">
            Real-time public safety, nearest critical services, and rapid emergency dispatch.
          </p>
        </div>

        {/* Safe Status Indicator */}
        <div
          className={`flex items-center gap-3 px-5 py-3 rounded-full shadow-sm border transition-colors cursor-pointer ${
            isSosActive
              ? 'bg-[#ffdad6] border-[#ba1a1a] text-[#93000a]'
              : 'bg-[#85f8c4] border-[#006243] text-[#002114]'
          }`}
          onClick={() => isSosActive && onSelectTab('live-sos')}
        >
          <span
            className={`material-symbols-outlined fill ${
              isSosActive ? 'text-[#ba1a1a] animate-pulse' : 'text-[#006243]'
            }`}
          >
            {isSosActive ? 'emergency' : 'verified_user'}
          </span>
          <span className="font-bold text-sm tracking-wider uppercase">
            {isSosActive ? 'STATUS: SOS BROADCASTING' : 'STATUS: SECURE'}
          </span>
        </div>
      </header>

      {/* Bento Grid Top Row: SOS Action & 4 Emergency Services Action Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Primary SOS Action (Large Card) */}
        <div className="col-span-1 md:col-span-12 lg:col-span-8 bg-white rounded-2xl shadow-sm border border-[#c3c6d7] p-6 flex flex-col justify-center items-center text-center min-h-[320px] relative overflow-hidden">
          <div className="absolute inset-0 bg-[#bb0112]/5 pointer-events-none"></div>

          <h2 className="text-2xl font-semibold text-[#111c2d] mb-2 z-10">
            {isSosActive ? 'SOS Assistance Dispatched!' : 'Immediate Assistance Required?'}
          </h2>
          <p className="text-sm md:text-base text-[#434655] mb-8 max-w-md z-10">
            {isSosActive
              ? 'Emergency units are responding to your location. Click below to view live beacon map.'
              : 'Press and hold the button for 3 seconds to broadcast your emergency distress signal.'}
          </p>

          {/* SOS Circle Button with Progress Ring */}
          <button
            onMouseDown={startHold}
            onMouseUp={cancelHold}
            onMouseLeave={cancelHold}
            onTouchStart={startHold}
            onTouchEnd={cancelHold}
            className={`w-36 h-36 rounded-full flex flex-col items-center justify-center shadow-lg transition-all duration-300 transform active:scale-95 focus:outline-none relative select-none z-10 cursor-pointer ${
              isSosActive
                ? 'bg-[#006243] text-white'
                : isHolding
                ? 'bg-[#93000a] text-white scale-105 shadow-2xl'
                : 'bg-[#ba1a1a] text-white hover:bg-[#93000a]'
            }`}
          >
            <span className="material-symbols-outlined text-4xl mb-1 fill">
              {isSosActive ? 'check_circle' : 'sos'}
            </span>
            <span className="font-bold text-xs tracking-wider uppercase">
              {isSosActive ? 'DISPATCHED' : isHolding ? 'HOLDING...' : 'HOLD 3s'}
            </span>

            {/* SVG Ring for Visual Hold Feedback */}
            <svg
              className={`absolute inset-0 w-full h-full -rotate-90 pointer-events-none ${
                isHolding || isSosActive ? 'block' : 'hidden'
              }`}
              viewBox="0 0 100 100"
            >
              <circle
                cx="50"
                cy="50"
                r="46"
                fill="none"
                stroke="rgba(255, 255, 255, 0.25)"
                strokeWidth="8"
              />
              <circle
                cx="50"
                cy="50"
                r="46"
                fill="none"
                stroke={isSosActive ? '#85f8c4' : '#ffffff'}
                strokeWidth="8"
                strokeDasharray={circumference}
                strokeDashoffset={isSosActive ? 0 : strokeOffset}
                className="transition-all duration-75"
              />
            </svg>
          </button>

          <div className="mt-4 font-semibold text-sm min-h-[24px] z-10">
            {isSosActive ? (
              <button
                onClick={() => onSelectTab('live-sos')}
                className="text-[#006243] hover:underline font-bold flex items-center gap-1 mx-auto"
              >
                <span>GPS Coordinates Broadcasting — View Live SOS Map</span>
                <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </button>
            ) : (
              <span className="text-[#bb0112]">{sosStatusText}</span>
            )}
          </div>
        </div>

        {/* 4 Core Emergency Services Quick Action Tiles (2x2 Grid) */}
        <div className="col-span-1 md:col-span-12 lg:col-span-4 grid grid-cols-2 gap-4">
          {/* Hospital Tile */}
          <button
            onClick={() => handleNavigateToCategory('hospital')}
            className="bg-white border border-[#c3c6d7] rounded-xl p-4 flex flex-col items-center justify-center text-center hover:bg-[#dbe1ff]/30 hover:border-[#004ac6] transition-all shadow-xs active:scale-98 cursor-pointer group relative overflow-hidden"
          >
            <div className="w-12 h-12 rounded-full bg-[#dbe1ff] text-[#004ac6] flex items-center justify-center mb-2.5 group-hover:scale-110 transition-transform">
              <span className="material-symbols-outlined fill text-2xl">local_hospital</span>
            </div>
            <span className="font-bold text-sm text-[#111c2d]">Nearest Hospital</span>
            <span className="text-xs text-[#004ac6] font-semibold mt-0.5">
              {nearestHospital ? `${nearestHospital.distance} • 24/7 ER` : 'Emergency Room'}
            </span>
          </button>

          {/* Police Station Tile */}
          <button
            onClick={() => handleNavigateToCategory('police')}
            className="bg-white border border-[#c3c6d7] rounded-xl p-4 flex flex-col items-center justify-center text-center hover:bg-[#dee8ff]/30 hover:border-[#003ea8] transition-all shadow-xs active:scale-98 cursor-pointer group relative overflow-hidden"
          >
            <div className="w-12 h-12 rounded-full bg-[#dee8ff] text-[#003ea8] flex items-center justify-center mb-2.5 group-hover:scale-110 transition-transform">
              <span className="material-symbols-outlined fill text-2xl">local_police</span>
            </div>
            <span className="font-bold text-sm text-[#111c2d]">Police Station</span>
            <span className="text-xs text-[#003ea8] font-semibold mt-0.5">
              {nearestPolice ? `${nearestPolice.distance} • 911 Hub` : 'Public Safety Desk'}
            </span>
          </button>

          {/* Fire Department Tile */}
          <button
            onClick={() => handleNavigateToCategory('fire')}
            className="bg-white border border-[#c3c6d7] rounded-xl p-4 flex flex-col items-center justify-center text-center hover:bg-[#ffdad6]/30 hover:border-[#ba1a1a] transition-all shadow-xs active:scale-98 cursor-pointer group relative overflow-hidden"
          >
            <div className="w-12 h-12 rounded-full bg-[#ffdad6] text-[#ba1a1a] flex items-center justify-center mb-2.5 group-hover:scale-110 transition-transform">
              <span className="material-symbols-outlined fill text-2xl">local_fire_department</span>
            </div>
            <span className="font-bold text-sm text-[#111c2d]">Fire & Rescue</span>
            <span className="text-xs text-[#ba1a1a] font-semibold mt-0.5">
              {nearestFire ? `${nearestFire.distance} • Station 1` : 'Rescue & Hazmat'}
            </span>
          </button>

          {/* Ambulance Service Tile */}
          <button
            onClick={() => handleNavigateToCategory('ambulance')}
            className="bg-white border border-[#c3c6d7] rounded-xl p-4 flex flex-col items-center justify-center text-center hover:bg-[#bdffdc]/30 hover:border-[#006243] transition-all shadow-xs active:scale-98 cursor-pointer group relative overflow-hidden"
          >
            <div className="w-12 h-12 rounded-full bg-[#bdffdc] text-[#006243] flex items-center justify-center mb-2.5 group-hover:scale-110 transition-transform">
              <span className="material-symbols-outlined fill text-2xl">ambulance</span>
            </div>
            <span className="font-bold text-sm text-[#111c2d]">Ambulance</span>
            <span className="text-xs text-[#006243] font-semibold mt-0.5">
              {nearestAmbulance ? `${nearestAmbulance.distance} • Rapid ALS` : 'Rapid Paramedic'}
            </span>
          </button>
        </div>
      </div>

      {/* Nearest 4 Emergency Services Proximity Directory */}
      <div className="w-full bg-white rounded-2xl shadow-sm border border-[#c3c6d7] p-6 flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#c3c6d7] pb-3">
          <div className="flex items-center gap-2.5">
            <span className="material-symbols-outlined text-[#004ac6] text-2xl">near_me</span>
            <div>
              <h2 className="text-xl font-bold text-[#111c2d]">Nearest Emergency Services</h2>
              <p className="text-xs text-[#434655]">Real-time GPS proximity to closest Hospital, Police Station, Fire Department, and Ambulance Dispatch</p>
            </div>
          </div>
          <button
            onClick={() => onSelectTab('locate')}
            className="text-xs font-bold text-[#004ac6] hover:underline flex items-center gap-1 self-start sm:self-auto cursor-pointer"
          >
            <span>View Full Directory & Live Map</span>
            <span className="material-symbols-outlined text-sm">arrow_forward</span>
          </button>
        </div>

        {/* 4 Cards Responsive Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Nearest Hospital Card */}
          {nearestHospital && (
            <div className="bg-[#f9f9ff] border border-[#c3c6d7] rounded-xl p-4 flex flex-col justify-between hover:border-[#004ac6] transition-all shadow-xs relative overflow-hidden group">
              <div className="absolute top-0 left-0 right-0 h-1 bg-[#004ac6]"></div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full uppercase bg-[#dbe1ff] text-[#004ac6]">
                    HOSPITAL & ER
                  </span>
                  <span className="text-xs font-bold text-[#004ac6] flex items-center gap-0.5">
                    <span className="material-symbols-outlined text-xs">near_me</span>
                    {nearestHospital.distance}
                  </span>
                </div>
                <h3 className="font-bold text-sm text-[#111c2d] mb-1 line-clamp-1">{nearestHospital.name}</h3>
                <p className="text-xs text-[#434655] mb-2 line-clamp-1">{nearestHospital.address}</p>
                <div className="flex flex-wrap gap-1 mb-3">
                  {nearestHospital.badges.slice(0, 2).map((b, i) => (
                    <span key={i} className="text-[10px] bg-white border border-[#c3c6d7] text-[#434655] px-1.5 py-0.5 rounded font-medium">
                      {b}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex items-center gap-2 pt-2 border-t border-[#c3c6d7]">
                <button
                  onClick={() => setSelectedDirectionFacility(nearestHospital)}
                  className="flex-1 bg-[#004ac6] text-white hover:bg-[#003ea8] text-xs font-semibold py-1.5 px-2 rounded-lg flex items-center justify-center gap-1 transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm">directions</span>
                  <span>Route</span>
                </button>
                <a
                  href={`tel:${nearestHospital.phone}`}
                  className="bg-white border border-[#c3c6d7] hover:bg-[#f0f3ff] text-[#111c2d] text-xs font-semibold p-1.5 rounded-lg flex items-center justify-center transition-colors"
                  title={`Call ${nearestHospital.name}`}
                >
                  <span className="material-symbols-outlined text-sm text-[#004ac6]">call</span>
                </a>
              </div>
            </div>
          )}

          {/* Nearest Police Station Card */}
          {nearestPolice && (
            <div className="bg-[#f9f9ff] border border-[#c3c6d7] rounded-xl p-4 flex flex-col justify-between hover:border-[#003ea8] transition-all shadow-xs relative overflow-hidden group">
              <div className="absolute top-0 left-0 right-0 h-1 bg-[#003ea8]"></div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full uppercase bg-[#dee8ff] text-[#003ea8]">
                    POLICE PRECINCT
                  </span>
                  <span className="text-xs font-bold text-[#003ea8] flex items-center gap-0.5">
                    <span className="material-symbols-outlined text-xs">near_me</span>
                    {nearestPolice.distance}
                  </span>
                </div>
                <h3 className="font-bold text-sm text-[#111c2d] mb-1 line-clamp-1">{nearestPolice.name}</h3>
                <p className="text-xs text-[#434655] mb-2 line-clamp-1">{nearestPolice.address}</p>
                <div className="flex flex-wrap gap-1 mb-3">
                  {nearestPolice.badges.slice(0, 2).map((b, i) => (
                    <span key={i} className="text-[10px] bg-white border border-[#c3c6d7] text-[#434655] px-1.5 py-0.5 rounded font-medium">
                      {b}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex items-center gap-2 pt-2 border-t border-[#c3c6d7]">
                <button
                  onClick={() => setSelectedDirectionFacility(nearestPolice)}
                  className="flex-1 bg-[#003ea8] text-white hover:bg-[#002f80] text-xs font-semibold py-1.5 px-2 rounded-lg flex items-center justify-center gap-1 transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm">directions</span>
                  <span>Route</span>
                </button>
                <a
                  href={`tel:${nearestPolice.phone}`}
                  className="bg-white border border-[#c3c6d7] hover:bg-[#f0f3ff] text-[#111c2d] text-xs font-semibold p-1.5 rounded-lg flex items-center justify-center transition-colors"
                  title={`Call ${nearestPolice.name}`}
                >
                  <span className="material-symbols-outlined text-sm text-[#003ea8]">call</span>
                </a>
              </div>
            </div>
          )}

          {/* Nearest Fire Station Card */}
          {nearestFire && (
            <div className="bg-[#f9f9ff] border border-[#c3c6d7] rounded-xl p-4 flex flex-col justify-between hover:border-[#ba1a1a] transition-all shadow-xs relative overflow-hidden group">
              <div className="absolute top-0 left-0 right-0 h-1 bg-[#ba1a1a]"></div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full uppercase bg-[#ffdad6] text-[#93000a]">
                    FIRE & RESCUE
                  </span>
                  <span className="text-xs font-bold text-[#ba1a1a] flex items-center gap-0.5">
                    <span className="material-symbols-outlined text-xs">near_me</span>
                    {nearestFire.distance}
                  </span>
                </div>
                <h3 className="font-bold text-sm text-[#111c2d] mb-1 line-clamp-1">{nearestFire.name}</h3>
                <p className="text-xs text-[#434655] mb-2 line-clamp-1">{nearestFire.address}</p>
                <div className="flex flex-wrap gap-1 mb-3">
                  {nearestFire.badges.slice(0, 2).map((b, i) => (
                    <span key={i} className="text-[10px] bg-white border border-[#c3c6d7] text-[#434655] px-1.5 py-0.5 rounded font-medium">
                      {b}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex items-center gap-2 pt-2 border-t border-[#c3c6d7]">
                <button
                  onClick={() => setSelectedDirectionFacility(nearestFire)}
                  className="flex-1 bg-[#ba1a1a] text-white hover:bg-[#93000a] text-xs font-semibold py-1.5 px-2 rounded-lg flex items-center justify-center gap-1 transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm">directions</span>
                  <span>Route</span>
                </button>
                <a
                  href={`tel:${nearestFire.phone}`}
                  className="bg-white border border-[#c3c6d7] hover:bg-[#f0f3ff] text-[#111c2d] text-xs font-semibold p-1.5 rounded-lg flex items-center justify-center transition-colors"
                  title={`Call ${nearestFire.name}`}
                >
                  <span className="material-symbols-outlined text-sm text-[#ba1a1a]">call</span>
                </a>
              </div>
            </div>
          )}

          {/* Nearest Ambulance Dispatch Card */}
          {nearestAmbulance && (
            <div className="bg-[#f9f9ff] border border-[#c3c6d7] rounded-xl p-4 flex flex-col justify-between hover:border-[#006243] transition-all shadow-xs relative overflow-hidden group">
              <div className="absolute top-0 left-0 right-0 h-1 bg-[#006243]"></div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full uppercase bg-[#bdffdc] text-[#005137]">
                    AMBULANCE / EMS
                  </span>
                  <span className="text-xs font-bold text-[#006243] flex items-center gap-0.5">
                    <span className="material-symbols-outlined text-xs">near_me</span>
                    {nearestAmbulance.distance}
                  </span>
                </div>
                <h3 className="font-bold text-sm text-[#111c2d] mb-1 line-clamp-1">{nearestAmbulance.name}</h3>
                <p className="text-xs text-[#434655] mb-2 line-clamp-1">{nearestAmbulance.address}</p>
                <div className="flex flex-wrap gap-1 mb-3">
                  {nearestAmbulance.badges.slice(0, 2).map((b, i) => (
                    <span key={i} className="text-[10px] bg-white border border-[#c3c6d7] text-[#434655] px-1.5 py-0.5 rounded font-medium">
                      {b}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex items-center gap-2 pt-2 border-t border-[#c3c6d7]">
                <button
                  onClick={() => setSelectedDirectionFacility(nearestAmbulance)}
                  className="flex-1 bg-[#006243] text-white hover:bg-[#004e35] text-xs font-semibold py-1.5 px-2 rounded-lg flex items-center justify-center gap-1 transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm">directions</span>
                  <span>Route</span>
                </button>
                <a
                  href={`tel:${nearestAmbulance.phone}`}
                  className="bg-white border border-[#c3c6d7] hover:bg-[#f0f3ff] text-[#111c2d] text-xs font-semibold p-1.5 rounded-lg flex items-center justify-center transition-colors"
                  title={`Call ${nearestAmbulance.name}`}
                >
                  <span className="material-symbols-outlined text-sm text-[#006243]">call</span>
                </a>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Live Incident Feed (Full Width) */}
      <div className="col-span-1 md:col-span-12 bg-white rounded-2xl shadow-sm border border-[#c3c6d7] overflow-hidden flex flex-col">
        <div className="p-5 border-b border-[#c3c6d7] bg-[#f9f9ff] flex flex-wrap justify-between items-center gap-3">
          <h3 className="text-xl font-bold text-[#111c2d] flex items-center gap-2">
            <span className="material-symbols-outlined text-[#004ac6]">feed</span>
            <span>Live Incident Feed</span>
          </h3>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setFeedFilter('all')}
              className={`text-xs font-semibold px-3 py-1 rounded-full border transition-colors cursor-pointer ${
                feedFilter === 'all'
                  ? 'bg-[#004ac6] text-white border-[#004ac6]'
                  : 'bg-white text-[#434655] border-[#c3c6d7] hover:bg-[#f0f3ff]'
              }`}
            >
              All Feed
            </button>
            <button
              onClick={() => setFeedFilter('accident')}
              className={`text-xs font-semibold px-3 py-1 rounded-full border transition-colors cursor-pointer ${
                feedFilter === 'accident'
                  ? 'bg-[#004ac6] text-white border-[#004ac6]'
                  : 'bg-white text-[#434655] border-[#c3c6d7] hover:bg-[#f0f3ff]'
              }`}
            >
              Accidents
            </button>
            <button
              onClick={() => setFeedFilter('hazard')}
              className={`text-xs font-semibold px-3 py-1 rounded-full border transition-colors cursor-pointer ${
                feedFilter === 'hazard'
                  ? 'bg-[#004ac6] text-white border-[#004ac6]'
                  : 'bg-white text-[#434655] border-[#c3c6d7] hover:bg-[#f0f3ff]'
              }`}
            >
              Hazards
            </button>

            <button
              onClick={() => onSelectTab('locate')}
              className="font-semibold text-sm text-[#004ac6] hover:underline flex items-center gap-1 ml-2 cursor-pointer"
            >
              <span>View Map</span>
              <span className="material-symbols-outlined text-sm">map</span>
            </button>
          </div>
        </div>

        <div className="divide-y divide-[#c3c6d7] max-h-[380px] overflow-y-auto">
          {filteredIncidents.map((item) => (
            <div
              key={item.id}
              className="p-4 hover:bg-[#f0f3ff] transition-colors flex gap-4 items-start cursor-pointer"
              onClick={() => onSelectTab('locate')}
            >
              <div className={`mt-1.5 w-2.5 h-2.5 rounded-full ${item.severityColor} shrink-0`}></div>
              <div className="flex-grow">
                <div className="flex justify-between items-baseline mb-1">
                  <h4 className="font-semibold text-base text-[#111c2d]">{item.title}</h4>
                  <span className="text-xs font-medium text-[#434655]">{item.timeAgo}</span>
                </div>
                <p className="text-sm text-[#434655] leading-normal">{item.description}</p>
                <div className="mt-2 flex items-center gap-2 text-xs text-[#737686]">
                  <span className="material-symbols-outlined text-xs">location_on</span>
                  <span>{item.locationName}</span>
                </div>
              </div>
            </div>
          ))}

          {filteredIncidents.length === 0 && (
            <div className="p-8 text-center text-[#737686] text-sm">
              No active incidents found in this filter category.
            </div>
          )}
        </div>
      </div>

      {/* Directions Modal when triggered from Dashboard */}
      {selectedDirectionFacility && (
        <DirectionsModal
          facility={selectedDirectionFacility}
          userLocation={{
            lat: 47.6062,
            lng: -122.3321,
            address: '47°36\'22.1"N 122°19\'55.4"W (Downtown Sector)',
          }}
          onClose={() => setSelectedDirectionFacility(null)}
          onCallFacility={(phone) => window.open(`tel:${phone}`)}
        />
      )}
    </div>
  );
};
