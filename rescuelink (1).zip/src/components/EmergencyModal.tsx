import React, { useState } from 'react';

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerSos: () => void;
}

export const EmergencyModal: React.FC<EmergencyModalProps> = ({
  isOpen,
  onClose,
  onTriggerSos,
}) => {
  const [callStatus, setCallStatus] = useState<'idle' | 'calling' | 'connected'>('idle');

  if (!isOpen) return null;

  const handleStartCall = () => {
    setCallStatus('calling');
    setTimeout(() => {
      setCallStatus('connected');
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border-2 border-[#ffb4ab] animate-in fade-in zoom-in duration-200">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-[#ffdad6] text-[#bb0112] flex items-center justify-center">
              <span className="material-symbols-outlined text-2xl fill">call</span>
            </div>
            <div>
              <h3 className="text-xl font-bold text-[#111c2d]">Emergency Hotline</h3>
              <p className="text-xs text-[#434655]">Direct connection to local dispatch authorities</p>
            </div>
          </div>
          <button
            onClick={() => {
              setCallStatus('idle');
              onClose();
            }}
            className="text-[#737686] hover:text-[#111c2d] p-1 rounded-full hover:bg-[#f0f3ff]"
          >
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        {callStatus === 'idle' && (
          <div className="space-y-4">
            <p className="text-sm text-[#434655]">
              Select an action below to establish immediate contact with emergency service dispatch.
            </p>

            <div className="space-y-2">
              <button
                onClick={handleStartCall}
                className="w-full bg-[#bb0112] text-white p-4 rounded-xl font-bold flex items-center justify-between hover:bg-[#e02928] transition-colors shadow-md"
              >
                <div className="flex items-center gap-3">
                  <span className="material-symbols-outlined fill text-2xl">phone_in_talk</span>
                  <div className="text-left">
                    <div className="text-base">Call 911 / Local Emergency</div>
                    <div className="text-xs font-normal opacity-90">Audio call with emergency operator</div>
                  </div>
                </div>
                <span className="material-symbols-outlined">arrow_forward</span>
              </button>

              <button
                onClick={() => {
                  onClose();
                  onTriggerSos();
                }}
                className="w-full bg-[#2563eb] text-white p-4 rounded-xl font-bold flex items-center justify-between hover:bg-[#003ea8] transition-colors shadow-sm"
              >
                <div className="flex items-center gap-3">
                  <span className="material-symbols-outlined fill text-2xl">emergency_home</span>
                  <div className="text-left">
                    <div className="text-base">Activate Silent SOS Beacon</div>
                    <div className="text-xs font-normal opacity-90">Broadcast live GPS coordinates instantly</div>
                  </div>
                </div>
                <span className="material-symbols-outlined">arrow_forward</span>
              </button>

              <button
                onClick={() => {
                  alert('Opening text dispatch channel...');
                }}
                className="w-full bg-[#f0f3ff] text-[#111c2d] border border-[#c3c6d7] p-4 rounded-xl font-semibold flex items-center justify-between hover:bg-[#d8e3fb] transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-2xl text-[#004ac6]">sms</span>
                  <div className="text-left">
                    <div className="text-base">Text Dispatch (911 SMS)</div>
                    <div className="text-xs font-normal text-[#434655]">For non-verbal or quiet situations</div>
                  </div>
                </div>
                <span className="material-symbols-outlined text-[#737686]">arrow_forward</span>
              </button>
            </div>
          </div>
        )}

        {callStatus === 'calling' && (
          <div className="py-8 text-center space-y-4">
            <div className="w-20 h-20 bg-[#ffdad6] rounded-full mx-auto flex items-center justify-center animate-pulse">
              <span className="material-symbols-outlined text-4xl text-[#bb0112] fill">call</span>
            </div>
            <div>
              <h4 className="text-lg font-bold text-[#111c2d]">Connecting to Dispatch...</h4>
              <p className="text-sm text-[#434655]">Routing through local cell network and GPS server</p>
            </div>
          </div>
        )}

        {callStatus === 'connected' && (
          <div className="py-6 text-center space-y-4">
            <div className="w-20 h-20 bg-[#85f8c4] rounded-full mx-auto flex items-center justify-center">
              <span className="material-symbols-outlined text-4xl text-[#006243] fill">check_circle</span>
            </div>
            <div>
              <h4 className="text-lg font-bold text-[#006243]">Call Connected</h4>
              <p className="text-sm text-[#434655]">Location data (47°36'22"N) transmitted to operator.</p>
            </div>
            <button
              onClick={() => {
                setCallStatus('idle');
                onClose();
              }}
              className="bg-[#bb0112] text-white px-6 py-2 rounded-full font-bold text-sm hover:bg-[#e02928]"
            >
              End Call
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
