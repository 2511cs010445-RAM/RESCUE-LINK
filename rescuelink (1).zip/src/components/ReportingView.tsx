import React, { useState } from 'react';
import { IncidentReportSubmission } from '../types';
import { analyzeReportWithAI, AIAnalysisResult, reverseGeocode } from '../services/api';

interface ReportingViewProps {
  submissions: IncidentReportSubmission[];
  onSubmitNewReport: (newReport: Omit<IncidentReportSubmission, 'id' | 'submittedAt' | 'status'>) => void;
  onUpgradeToSos: () => void;
  initialCategory?: string;
}

export const ReportingView: React.FC<ReportingViewProps> = ({
  submissions,
  onSubmitNewReport,
  onUpgradeToSos,
  initialCategory = '',
}) => {
  const [category, setCategory] = useState(initialCategory || '');
  const [description, setDescription] = useState('');
  const [locationAddress, setLocationAddress] = useState('789 Howard St, Substation B');
  const [pinCoords, setPinCoords] = useState<{ x: number; y: number }>({ x: 50, y: 50 });
  const [hasEvidence, setHasEvidence] = useState(false);
  const [fileName, setFileName] = useState('');
  const [isSuccessMessage, setIsSuccessMessage] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [selectedSubmission, setSelectedSubmission] = useState<IncidentReportSubmission | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiResult, setAiResult] = useState<AIAnalysisResult | null>(null);

  const handleAiTriage = async () => {
    if (!description.trim()) {
      alert('Please enter a description first to evaluate with AI triage.');
      return;
    }
    setIsAnalyzing(true);
    try {
      const result = await analyzeReportWithAI(description, category);
      setAiResult(result);
      if (result.suggestedCategory && !category) {
        setCategory(result.suggestedCategory);
      }
    } catch (err) {
      console.error('AI Triage error:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleMapClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.round(((e.clientX - rect.left) / rect.width) * 100);
    const y = Math.round(((e.clientY - rect.top) / rect.height) * 100);
    setPinCoords({ x, y });
    setLocationAddress(`Grid Marker Sector (${x}°N, ${y}°W)`);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setHasEvidence(true);
      setFileName(e.target.files[0].name);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!category || !description.trim()) {
      alert('Please fill in the incident classification and detailed description.');
      return;
    }

    onSubmitNewReport({
      category,
      description,
      location: {
        address: locationAddress,
        lat: 47.608 + pinCoords.y / 1000,
        lng: -122.335 + pinCoords.x / 1000,
      },
      hasEvidence,
      evidenceFileName: fileName || undefined,
    });

    setIsSuccessMessage(true);
    setCategory('');
    setDescription('');
    setHasEvidence(false);
    setFileName('');

    setTimeout(() => {
      setIsSuccessMessage(false);
    }, 4000);
  };

  return (
    <div className="flex-1 pt-20 pb-12 px-4 md:px-12 max-w-7xl mx-auto w-full flex flex-col gap-6 lg:pl-64">
      {/* Header Section */}
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl md:text-5xl font-bold text-[#111c2d]">Submit Incident Report</h1>
        <p className="text-base text-[#434655] max-w-2xl leading-relaxed">
          Use this form to document non-emergency field observations, safety hazards, or minor incidents. For immediate emergencies, use the Emergency Call function.
        </p>
      </div>

      {/* Success Banner */}
      {isSuccessMessage && (
        <div className="bg-[#85f8c4] text-[#002114] p-4 rounded-xl border border-[#006243] flex items-center gap-3 animate-in fade-in">
          <span className="material-symbols-outlined text-[#006243] text-2xl fill">check_circle</span>
          <div>
            <h4 className="font-bold text-sm">Report Submitted Successfully!</h4>
            <p className="text-xs text-[#005137]">Your report has been logged and queued for dispatch review.</p>
          </div>
        </div>
      )}

      {/* Grid Content */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Form Card (8 Columns) */}
        <div className="lg:col-span-8 bg-white rounded-xl border border-[#c3c6d7] shadow-sm overflow-hidden flex flex-col">
          {/* Progress Header */}
          <div className="bg-[#f0f3ff] border-b border-[#c3c6d7] p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-[#004ac6] text-white flex items-center justify-center text-sm font-bold">
                1
              </div>
              <span className="font-semibold text-lg text-[#111c2d]">Incident Details</span>
            </div>
            <span className="text-xs font-semibold text-[#434655]">Step 1 of 3</span>
          </div>

          <form onSubmit={handleSubmit} className="p-6 flex flex-col gap-6">
            {/* Input 1: Classification */}
            <div className="flex flex-col gap-1.5">
              <label className="font-semibold text-sm text-[#111c2d]" htmlFor="incidentType">
                Incident Classification *
              </label>
              <select
                id="incidentType"
                required
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="bg-[#f9f9ff] border border-[#c3c6d7] rounded-lg p-3 text-base text-[#111c2d] focus:outline-none focus:ring-2 focus:ring-[#004ac6] focus:border-transparent min-h-[48px]"
              >
                <option value="" disabled>
                  Select category...
                </option>
                <option value="Environmental Hazard">Environmental Hazard</option>
                <option value="Property Damage (Non-Urgent)">Property Damage (Non-Urgent)</option>
                <option value="Suspicious Activity Observation">Suspicious Activity Observation</option>
                <option value="Welfare Check Request">Welfare Check Request</option>
                <option value="Traffic Accident">Traffic Collision / Road Hazard</option>
                <option value="Other">Other</option>
              </select>
            </div>

            {/* Input 2: Description */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between items-center">
                <label className="font-semibold text-sm text-[#111c2d]" htmlFor="description">
                  Detailed Description *
                </label>
                <button
                  type="button"
                  onClick={handleAiTriage}
                  disabled={isAnalyzing}
                  className="text-xs font-semibold text-[#004ac6] hover:text-[#003ea8] flex items-center gap-1 bg-[#d8e3fb]/60 hover:bg-[#d8e3fb] px-2.5 py-1 rounded-md transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm">auto_awesome</span>
                  <span>{isAnalyzing ? 'Analyzing with AI...' : 'AI Dispatch Triage'}</span>
                </button>
              </div>
              <textarea
                id="description"
                required
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Provide objective details of the incident..."
                className="bg-[#f9f9ff] border border-[#c3c6d7] rounded-lg p-3 text-base text-[#111c2d] focus:outline-none focus:ring-2 focus:ring-[#004ac6] focus:border-transparent"
              ></textarea>

              {aiResult && (
                <div className="bg-[#f0f3ff] border border-[#004ac6]/30 rounded-lg p-3 mt-1 flex flex-col gap-1 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#004ac6] flex items-center gap-1">
                      <span className="material-symbols-outlined text-xs">psychology</span>
                      AI Triage Evaluation:
                    </span>
                    <span className={`px-2 py-0.5 rounded font-bold ${
                      aiResult.urgency === 'High' ? 'bg-[#ffdad6] text-[#ba1a1a]' : 'bg-[#dee8ff] text-[#004ac6]'
                    }`}>
                      Urgency: {aiResult.urgency}
                    </span>
                  </div>
                  {aiResult.recommendation && (
                    <p className="text-[#434655] mt-1"><span className="font-semibold">Recommendation:</span> {aiResult.recommendation}</p>
                  )}
                  {aiResult.urgency === 'High' && (
                    <button
                      type="button"
                      onClick={onUpgradeToSos}
                      className="mt-1 text-xs font-bold text-[#ba1a1a] underline hover:opacity-80 text-left"
                    >
                      High urgency detected — Click here to activate Live SOS Beacon immediately
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Section 2: Location Identification */}
            <div className="pt-4 border-t border-[#c3c6d7]">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#434655]">location_on</span>
                  <h3 className="font-semibold text-lg text-[#111c2d]">Location Identification</h3>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    if (navigator.geolocation) {
                      navigator.geolocation.getCurrentPosition(async (pos) => {
                        const { latitude, longitude } = pos.coords;
                        try {
                          const rev = await reverseGeocode(latitude, longitude);
                          if (rev && rev.address) {
                            setLocationAddress(rev.shortAddress || rev.address);
                          } else {
                            setLocationAddress(`${latitude.toFixed(4)}°N, ${longitude.toFixed(4)}°W`);
                          }
                        } catch {
                          setLocationAddress(`${latitude.toFixed(4)}°N, ${longitude.toFixed(4)}°W`);
                        }
                        setPinCoords({ x: 50, y: 50 });
                      });
                    }
                  }}
                  className="text-xs font-semibold text-[#004ac6] hover:text-[#003ea8] flex items-center gap-1 bg-[#d8e3fb]/60 hover:bg-[#d8e3fb] px-2.5 py-1 rounded-md transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm">my_location</span>
                  <span>Use My Live Location</span>
                </button>
              </div>

              <div
                onClick={handleMapClick}
                className="h-48 md:h-64 rounded-lg bg-[#e7eeff] overflow-hidden relative border border-[#c3c6d7] cursor-pointer group select-none shadow-inner"
              >
                {/* Map Graphic */}
                <img
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuDUXluOfNhQDq7u_cBIxESSYXA0eepszRll3cqk51M1NcP5wyYz0ETEXEz_R3r22QiAKAwalggkgKweMQ6WOpQIAJdwY8RCzbKe1G2Gn5Ymo302k98rQ0uUkPCMUyNI1AtpTFlMd2TUUUgiL7ZLJUt2eiOu5OahhPtjQofZxasxG7EfyfxsR3ZPEqYhbw7kG5GmNTFSCksRi-OBHtJvkt5GAozLt5ync-615hf0JdUaU7bmCd_LNRtb"
                  alt="City GIS Map View"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-90"
                />

                {/* Pin Marker */}
                <div
                  className="absolute z-20 transform -translate-x-1/2 -translate-y-full text-[#bb0112] drop-shadow-md transition-all"
                  style={{ left: `${pinCoords.x}%`, top: `${pinCoords.y}%` }}
                >
                  <span className="material-symbols-outlined text-4xl fill">location_on</span>
                </div>

                {/* Select Location Overlay Badge */}
                <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors flex items-center justify-center pointer-events-none">
                  <div className="bg-white/95 backdrop-blur-xs py-2 px-4 rounded-full shadow-md text-sm font-semibold text-[#111c2d] border border-[#c3c6d7] flex items-center gap-2">
                    <span className="material-symbols-outlined text-base">edit_location</span>
                    <span>Click Map to Select Precise Location</span>
                  </div>
                </div>
              </div>

              <p className="text-xs text-[#737686] mt-2">
                Selected Location Address: <span className="font-bold text-[#111c2d]">{locationAddress}</span>
              </p>
            </div>

            {/* Section 3: Evidence Collection */}
            <div className="pt-4 border-t border-[#c3c6d7]">
              <div className="flex items-center gap-2 mb-3">
                <span className="material-symbols-outlined text-[#434655]">perm_media</span>
                <h3 className="font-semibold text-lg text-[#111c2d]">Evidence Collection (Optional)</h3>
              </div>

              <label className="border-2 border-dashed border-[#c3c6d7] rounded-lg p-6 flex flex-col items-center justify-center text-center bg-[#f9f9ff] hover:bg-[#f0f3ff] transition-colors min-h-[120px] cursor-pointer">
                <input
                  type="file"
                  accept="image/*,video/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <span className="material-symbols-outlined text-3xl text-[#434655] mb-1">
                  cloud_upload
                </span>
                <span className="font-semibold text-sm text-[#111c2d]">
                  {fileName ? `Uploaded: ${fileName}` : 'Drag & drop files or click to browse'}
                </span>
                <span className="text-xs text-[#737686] mt-1">Supports JPG, PNG, MP4 (Max 50MB)</span>
              </label>
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-3 pt-4 border-t border-[#c3c6d7]">
              <button
                type="button"
                onClick={() => alert('Draft saved locally in browser state.')}
                className="px-5 py-2.5 rounded-lg font-semibold text-sm text-[#434655] hover:bg-[#d8e3fb] transition-colors min-h-[48px]"
              >
                Save Draft
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-lg font-semibold text-sm bg-[#004ac6] text-white hover:bg-[#003ea8] transition-colors shadow-sm min-h-[48px] flex items-center gap-2 cursor-pointer"
              >
                <span>Submit Report</span>
                <span className="material-symbols-outlined text-lg">send</span>
              </button>
            </div>
          </form>
        </div>

        {/* Status Tracker Sidebar (4 Columns) */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          <div className="bg-white rounded-xl border border-[#c3c6d7] shadow-sm overflow-hidden">
            <div className="bg-[#f0f3ff] border-b border-[#c3c6d7] p-4 flex items-center gap-2">
              <span className="material-symbols-outlined text-[#434655]">history</span>
              <h3 className="font-semibold text-lg text-[#111c2d]">Recent Submissions</h3>
            </div>

            <div className="p-4 flex flex-col gap-3">
              {submissions.map((sub) => (
                <div
                  key={sub.id}
                  onClick={() => setSelectedSubmission(sub)}
                  className="p-3.5 border border-[#c3c6d7] rounded-lg bg-[#f9f9ff] flex flex-col gap-1 hover:border-[#004ac6] transition-colors cursor-pointer group"
                >
                  <div className="flex justify-between items-start">
                    <span className="font-bold text-sm text-[#111c2d] group-hover:text-[#004ac6]">
                      {sub.id}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-xs font-semibold ${
                        sub.status === 'Resolved'
                          ? 'bg-[#85f8c4] text-[#002114]'
                          : sub.status === 'In Review'
                          ? 'bg-[#dee8ff] text-[#003ea8] border border-[#c3c6d7]'
                          : 'bg-[#ffdad6] text-[#410002]'
                      }`}
                    >
                      {sub.status}
                    </span>
                  </div>

                  <p className="text-sm text-[#434655] line-clamp-1">{sub.description}</p>
                  <span className="text-[11px] text-[#737686] mt-1">Submitted: {sub.submittedAt}</span>
                </div>
              ))}
            </div>

            <div className="p-3 border-t border-[#c3c6d7] bg-[#f9f9ff] text-center">
              <button
                onClick={() => setShowHistoryModal(true)}
                className="font-semibold text-sm text-[#004ac6] hover:underline"
              >
                View All History
              </button>
            </div>
          </div>

          {/* Processing Times Info Box */}
          <div className="bg-[#e7eeff] rounded-xl p-5 border border-[#c3c6d7] flex items-start gap-3">
            <span className="material-symbols-outlined text-[#004ac6] mt-0.5 text-2xl">info</span>
            <div>
              <h4 className="font-bold text-sm text-[#111c2d] mb-1">Processing Times</h4>
              <p className="text-xs text-[#434655] leading-relaxed">
                Non-emergency reports are typically reviewed within 24–48 hours. If situation escalates, upgrade to live SOS.
              </p>
              <button
                onClick={onUpgradeToSos}
                className="mt-3 text-xs font-bold text-[#bb0112] underline hover:opacity-80 block"
              >
                Upgrade to Live SOS Now
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* History / Detail Modal */}
      {(showHistoryModal || selectedSubmission) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-xl max-w-lg w-full p-6 shadow-2xl border border-[#c3c6d7] max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4 pb-2 border-b border-[#c3c6d7]">
              <h3 className="text-xl font-bold text-[#111c2d]">
                {selectedSubmission ? `Submission Details: ${selectedSubmission.id}` : 'Incident Report History'}
              </h3>
              <button
                onClick={() => {
                  setShowHistoryModal(false);
                  setSelectedSubmission(null);
                }}
                className="text-[#737686] hover:text-[#111c2d]"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            {selectedSubmission ? (
              <div className="space-y-4">
                <div className="flex justify-between items-center bg-[#f0f3ff] p-3 rounded-lg">
                  <div>
                    <div className="text-xs text-[#737686]">Classification</div>
                    <div className="text-sm font-bold text-[#111c2d]">{selectedSubmission.category}</div>
                  </div>
                  <span className="px-2.5 py-1 rounded text-xs font-bold bg-[#dee8ff] text-[#003ea8]">
                    {selectedSubmission.status}
                  </span>
                </div>

                <div>
                  <div className="text-xs text-[#737686] font-semibold">Detailed Description</div>
                  <p className="text-sm text-[#111c2d] mt-1 bg-[#f9f9ff] p-3 rounded-lg border border-[#c3c6d7]">
                    {selectedSubmission.description}
                  </p>
                </div>

                <div>
                  <div className="text-xs text-[#737686] font-semibold">Location</div>
                  <div className="text-sm text-[#111c2d] mt-1">{selectedSubmission.location.address}</div>
                </div>

                {selectedSubmission.hasEvidence && (
                  <div>
                    <div className="text-xs text-[#737686] font-semibold">Evidence Attached</div>
                    <div className="text-xs text-[#004ac6] mt-1 flex items-center gap-1">
                      <span className="material-symbols-outlined text-sm">attach_file</span>
                      <span>{selectedSubmission.evidenceFileName || 'Media_Evidence_Attachment.jpg'}</span>
                    </div>
                  </div>
                )}

                <button
                  onClick={() => setSelectedSubmission(null)}
                  className="w-full mt-4 py-2 bg-[#f0f3ff] text-[#004ac6] rounded-lg text-sm font-bold"
                >
                  Back to List
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {submissions.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => setSelectedSubmission(item)}
                    className="p-3 border border-[#c3c6d7] rounded-lg hover:bg-[#f0f3ff] cursor-pointer"
                  >
                    <div className="flex justify-between font-bold text-sm text-[#111c2d]">
                      <span>{item.id}</span>
                      <span className="text-xs text-[#004ac6]">{item.status}</span>
                    </div>
                    <p className="text-xs text-[#434655] mt-1 truncate">{item.description}</p>
                    <span className="text-[10px] text-[#737686]">{item.submittedAt}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
