import React, { useState } from 'react';
import { NavigationTab } from '../types';

interface TopNavBarProps {
  currentTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  onOpenEmergencyModal: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  isSosActive?: boolean;
}

export const TopNavBar: React.FC<TopNavBarProps> = ({
  currentTab,
  onSelectTab,
  onOpenEmergencyModal,
  searchQuery,
  onSearchChange,
  isSosActive = false,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  return (
    <nav className="bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs fixed top-0 w-full z-50 flex justify-between items-center px-4 md:px-8 lg:px-12 h-16 transition-all">
      {/* Brand & Desktop Navigation */}
      <div className="flex items-center gap-6 lg:gap-8">
        <button 
          onClick={() => onSelectTab('welcome')}
          className="group text-left flex items-center gap-2.5 hover:opacity-95 transition-all cursor-pointer select-none"
        >
          {/* RescueLink Modern Emblem */}
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#004ac6] via-[#1d63e6] to-[#0284c7] text-white flex items-center justify-center shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
            <span className="material-symbols-outlined text-2xl fill">local_hospital</span>
          </div>

          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-[#0f172a] text-xl md:text-2xl tracking-tight font-['Plus_Jakarta_Sans',sans-serif]">
                Rescue<span className="text-[#004ac6] bg-gradient-to-r from-[#004ac6] to-[#0284c7] bg-clip-text text-transparent">Link</span>
              </span>
              {isSosActive ? (
                <span className="bg-[#bb0112] text-white text-[10px] uppercase font-extrabold px-2 py-0.5 rounded-full animate-pulse shadow-xs">
                  SOS Active
                </span>
              ) : (
                <span className="hidden sm:inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  24/7 Grid
                </span>
              )}
            </div>
            <span className="text-[10px] text-slate-400 font-semibold tracking-wider uppercase -mt-0.5 hidden sm:block">
              Emergency & Public Safety
            </span>
          </div>
        </button>

        {/* Desktop Nav Items with Modern Floating Pills */}
        <div className="hidden md:flex items-center gap-1.5 lg:gap-2 ml-2 bg-slate-100/80 p-1 rounded-full border border-slate-200/80">
          <button
            onClick={() => onSelectTab('welcome')}
            className={`font-semibold text-xs lg:text-sm px-3.5 py-1.5 rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
              currentTab === 'welcome'
                ? 'bg-white text-[#004ac6] shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <span className="material-symbols-outlined text-base">home</span>
            <span>Welcome</span>
          </button>

          <button
            onClick={() => onSelectTab('dashboard')}
            className={`font-semibold text-xs lg:text-sm px-3.5 py-1.5 rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
              currentTab === 'dashboard'
                ? 'bg-white text-[#004ac6] shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <span className="material-symbols-outlined text-base">dashboard</span>
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => onSelectTab('incidents')}
            className={`font-semibold text-xs lg:text-sm px-3.5 py-1.5 rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
              currentTab === 'incidents'
                ? 'bg-white text-[#004ac6] shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <span className="material-symbols-outlined text-base">report</span>
            <span>Incidents</span>
          </button>

          <button
            onClick={() => onSelectTab('locate')}
            className={`font-semibold text-xs lg:text-sm px-3.5 py-1.5 rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
              currentTab === 'locate'
                ? 'bg-white text-[#004ac6] shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <span className="material-symbols-outlined text-base">near_me</span>
            <span>Locate Services</span>
          </button>

          {isSosActive && (
            <button
              onClick={() => onSelectTab('live-sos')}
              className={`font-bold text-xs lg:text-sm px-3.5 py-1.5 rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
                currentTab === 'live-sos'
                  ? 'bg-[#bb0112] text-white shadow-xs'
                  : 'bg-red-50 text-[#bb0112] hover:bg-red-100 animate-pulse'
              }`}
            >
              <span className="material-symbols-outlined text-base fill">emergency</span>
              <span>Live SOS</span>
            </button>
          )}
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-2.5 md:gap-3.5">
        {/* Search Bar */}
        <div className="hidden xl:flex items-center bg-slate-100/90 rounded-full px-3.5 py-1.5 border border-slate-200 focus-within:border-[#004ac6] focus-within:bg-white focus-within:ring-2 focus-within:ring-blue-100 transition-all">
          <span className="material-symbols-outlined text-slate-400 mr-2 text-base">search</span>
          <input
            type="text"
            placeholder="Search hospitals, police, roads..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="bg-transparent border-none focus:ring-0 text-xs w-44 outline-none text-slate-800 placeholder:text-slate-400 font-medium"
          />
          {searchQuery && (
            <button onClick={() => onSearchChange('')} className="text-slate-400 hover:text-slate-700">
              <span className="material-symbols-outlined text-xs">close</span>
            </button>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            aria-label="Notifications"
            className="p-2 rounded-full hover:bg-slate-100 text-slate-600 hover:text-[#004ac6] transition-colors relative cursor-pointer"
          >
            <span className="material-symbols-outlined text-xl">notifications</span>
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#bb0112] rounded-full ring-2 ring-white animate-pulse"></span>
          </button>

          {/* Notifications Dropdown Popup */}
          {showNotifications && (
            <div className="absolute right-0 top-12 w-84 bg-white rounded-2xl shadow-xl border border-slate-200 p-4 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
              <div className="flex justify-between items-center mb-3 pb-2 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-red-500"></span>
                  <h4 className="font-bold text-xs uppercase tracking-wider text-slate-800">RescueLink Broadcasts</h4>
                </div>
                <button
                  onClick={() => setShowNotifications(false)}
                  className="text-xs font-semibold text-slate-400 hover:text-slate-700 cursor-pointer"
                >
                  Dismiss
                </button>
              </div>
              <div className="space-y-2.5 max-h-64 overflow-y-auto">
                <div className="p-3 bg-red-50/80 rounded-xl border border-red-200/80">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-bold text-red-700">High-Priority Alert</p>
                    <span className="text-[10px] text-red-500 font-medium">Just now</span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">Suraram X Road junction patrol unit dispatched for lane clearance.</p>
                </div>
                <div className="p-3 bg-blue-50/80 rounded-xl border border-blue-200/80">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-bold text-blue-700">Telangana Safety Grid</p>
                    <span className="text-[10px] text-blue-500 font-medium">Active</span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">Dial 100, 108 & 101 emergency telematics linked with 40+ medical centers.</p>
                </div>
              </div>
            </div>
          )}

          <button
            onClick={() => onSelectTab('incidents')}
            aria-label="Profile"
            className="p-2 rounded-full hover:bg-slate-100 text-slate-600 hover:text-[#004ac6] transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-xl">account_circle</span>
          </button>
        </div>

        {/* Emergency Call Action Button */}
        <button
          onClick={onOpenEmergencyModal}
          className="flex items-center gap-1.5 sm:gap-2 bg-gradient-to-r from-[#bb0112] to-[#dc2626] text-white px-3.5 sm:px-4 py-2 rounded-full font-bold text-xs sm:text-sm hover:from-[#a00110] hover:to-[#b91c1c] transition-all shadow-md shadow-red-500/20 active:scale-98 cursor-pointer"
        >
          <span className="material-symbols-outlined text-base sm:text-lg fill animate-pulse">call</span>
          <span className="tracking-tight">Emergency Call</span>
        </button>

        {/* Mobile Menu Toggle */}
        <button
          onClick={() => setShowMobileMenu(!showMobileMenu)}
          className="md:hidden p-2 text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          aria-label="Toggle Menu"
        >
          <span className="material-symbols-outlined">{showMobileMenu ? 'close' : 'menu'}</span>
        </button>
      </div>

      {/* Mobile Menu Drawer */}
      {showMobileMenu && (
        <div className="md:hidden absolute top-16 left-0 w-full bg-white border-b border-slate-200 p-4 flex flex-col gap-2 shadow-xl z-50 animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center justify-between px-2 pb-2 border-b border-slate-100">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Navigation</span>
            <span className="text-xs text-emerald-600 font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              RescueLink Online
            </span>
          </div>

          <button
            onClick={() => {
              onSelectTab('welcome');
              setShowMobileMenu(false);
            }}
            className={`text-left font-semibold text-sm py-2.5 px-3.5 rounded-xl flex items-center gap-2.5 transition-colors ${
              currentTab === 'welcome' ? 'bg-[#004ac6] text-white' : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <span className="material-symbols-outlined text-lg">home</span>
            <span>Welcome Portal</span>
          </button>

          <button
            onClick={() => {
              onSelectTab('dashboard');
              setShowMobileMenu(false);
            }}
            className={`text-left font-semibold text-sm py-2.5 px-3.5 rounded-xl flex items-center gap-2.5 transition-colors ${
              currentTab === 'dashboard' ? 'bg-[#004ac6] text-white' : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <span className="material-symbols-outlined text-lg">dashboard</span>
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => {
              onSelectTab('incidents');
              setShowMobileMenu(false);
            }}
            className={`text-left font-semibold text-sm py-2.5 px-3.5 rounded-xl flex items-center gap-2.5 transition-colors ${
              currentTab === 'incidents' ? 'bg-[#004ac6] text-white' : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <span className="material-symbols-outlined text-lg">report</span>
            <span>Incident Reporting</span>
          </button>

          <button
            onClick={() => {
              onSelectTab('locate');
              setShowMobileMenu(false);
            }}
            className={`text-left font-semibold text-sm py-2.5 px-3.5 rounded-xl flex items-center gap-2.5 transition-colors ${
              currentTab === 'locate' ? 'bg-[#004ac6] text-white' : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <span className="material-symbols-outlined text-lg">near_me</span>
            <span>Locate Services</span>
          </button>

          <button
            onClick={() => {
              onSelectTab('live-sos');
              setShowMobileMenu(false);
            }}
            className={`text-left font-bold text-sm py-2.5 px-3.5 rounded-xl flex items-center gap-2.5 transition-colors ${
              currentTab === 'live-sos' ? 'bg-[#bb0112] text-white' : 'bg-red-50 text-[#bb0112]'
            }`}
          >
            <span className="material-symbols-outlined text-lg fill">emergency</span>
            <span>Live SOS Beacon</span>
          </button>
        </div>
      )}
    </nav>
  );
};
