import React, { useState, useEffect, useCallback } from 'react';
import {
  IncidentFeedItem,
  NavigationTab,
  EmergencyContact,
  IncidentReportSubmission,
  NearbyFacility,
  SystemAdvisory,
  FacilityCategory,
} from './types';
import {
  INITIAL_ADVISORY,
  INITIAL_INCIDENTS,
  INITIAL_CONTACTS,
  INITIAL_SUBMISSIONS,
  NEARBY_FACILITIES,
} from './data/mockData';
import {
  fetchAdvisory,
  fetchIncidents,
  fetchContacts,
  fetchReports,
  fetchFacilities,
  fetchSosStatus,
  triggerSosBeacon,
  cancelSosBeacon,
  addContact as apiAddContact,
  submitReport,
} from './services/api';

import { TopNavBar } from './components/TopNavBar';
import { SideNavBar } from './components/SideNavBar';
import { Footer } from './components/Footer';
import { EmergencyModal } from './components/EmergencyModal';

import { DashboardView } from './components/DashboardView';
import { LiveSosView } from './components/LiveSosView';
import { ReportingView } from './components/ReportingView';
import { LocateView } from './components/LocateView';
import { WelcomeOpeningView } from './components/WelcomeOpeningView';

export function App() {
  const [currentTab, setCurrentTab] = useState<NavigationTab>('welcome');
  const [isEmergencyModalOpen, setIsEmergencyModalOpen] = useState<boolean>(false);
  const [isSosActive, setIsSosActive] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Live state with persistent fallbacks
  const [advisory, setAdvisory] = useState<SystemAdvisory>(INITIAL_ADVISORY);
  const [incidents, setIncidents] = useState<IncidentFeedItem[]>(INITIAL_INCIDENTS);
  const [contacts, setContacts] = useState<EmergencyContact[]>(INITIAL_CONTACTS);
  const [submissions, setSubmissions] = useState<IncidentReportSubmission[]>(INITIAL_SUBMISSIONS);
  const [facilities, setFacilities] = useState<NearbyFacility[]>(NEARBY_FACILITIES);
  const [initialCategory, setInitialCategory] = useState<string>('');
  const [selectedLocateCategory, setSelectedLocateCategory] = useState<FacilityCategory | 'all'>('all');
  const [backendConnected, setBackendConnected] = useState<boolean>(true);

  // Load all initial data from backend
  const loadBackendData = useCallback(async () => {
    try {
      const [advData, incData, contData, repData, facData, sosData] = await Promise.allSettled([
        fetchAdvisory(),
        fetchIncidents(),
        fetchContacts(),
        fetchReports(),
        fetchFacilities(),
        fetchSosStatus(),
      ]);

      if (advData.status === 'fulfilled' && advData.value) setAdvisory(advData.value);
      if (incData.status === 'fulfilled' && incData.value) setIncidents(incData.value);
      if (contData.status === 'fulfilled' && contData.value) setContacts(contData.value);
      if (repData.status === 'fulfilled' && repData.value) setSubmissions(repData.value);
      if (facData.status === 'fulfilled' && facData.value) setFacilities(facData.value);
      if (sosData.status === 'fulfilled' && sosData.value) {
        setIsSosActive(sosData.value.isActive);
      }
      setBackendConnected(true);
    } catch (err) {
      console.warn('Backend sync notice (using local fallback data):', err);
      setBackendConnected(false);
    }
  }, []);

  useEffect(() => {
    loadBackendData();
    // Poll data every 10 seconds for real-time dispatch synchronization
    const interval = setInterval(loadBackendData, 10000);
    return () => clearInterval(interval);
  }, [loadBackendData]);

  const handleTriggerSos = async () => {
    setIsSosActive(true);
    setCurrentTab('live-sos');
    try {
      await triggerSosBeacon({
        address: '47°36\'22.1"N 122°19\'55.4"W (Downtown Sector)',
        lat: 47.6062,
        lng: -122.3321,
      });
      // Refresh incidents to reflect newly added SOS beacon alert
      const updatedIncidents = await fetchIncidents();
      setIncidents(updatedIncidents);
    } catch (err) {
      console.error('Failed to broadcast SOS to backend:', err);
    }
  };

  const handleCancelSos = async () => {
    setIsSosActive(false);
    setCurrentTab('dashboard');
    try {
      await cancelSosBeacon();
    } catch (err) {
      console.error('Failed to cancel SOS on backend:', err);
    }
  };

  const handleAddContact = async (name: string, role: string, phone: string) => {
    try {
      const created = await apiAddContact(name, role, phone);
      setContacts((prev) => [created, ...prev]);
    } catch {
      // Local fallback
      const newContact: EmergencyContact = {
        id: `c-${Date.now()}`,
        name,
        role: role || 'Emergency Contact',
        status: 'delivered',
        statusMessage: 'Message Delivered (Just now)',
        phone,
        timeAgo: 'Just now',
      };
      setContacts((prev) => [newContact, ...prev]);
    }
  };

  const handleSubmitNewReport = async (
    newReportData: Omit<IncidentReportSubmission, 'id' | 'submittedAt' | 'status'>
  ) => {
    try {
      const { submission, feedItem } = await submitReport(newReportData);
      setSubmissions((prev) => [submission, ...prev]);
      setIncidents((prev) => [feedItem, ...prev]);
    } catch {
      // Local fallback
      const newId = `INC-2024-${Math.floor(1000 + Math.random() * 9000)}`;
      const newSubmission: IncidentReportSubmission = {
        ...newReportData,
        id: newId,
        status: 'In Review',
        submittedAt: 'Just now',
      };

      setSubmissions((prev) => [newSubmission, ...prev]);

      const newFeedItem: IncidentFeedItem = {
        id: `feed-${Date.now()}`,
        title: `${newReportData.category} - ${newReportData.location.address}`,
        category: 'hazard',
        description: newReportData.description,
        timeAgo: 'Just now',
        timestamp: 'Now',
        severityColor: 'bg-[#004ac6]',
        locationName: newReportData.location.address,
      };
      setIncidents((prev) => [newFeedItem, ...prev]);
    }
  };

  const handleQuickCategoryClick = (category: string) => {
    setInitialCategory(category);
  };

  const handleSelectFacilityCategory = (category: FacilityCategory) => {
    setSelectedLocateCategory(category);
    setCurrentTab('locate');
  };

  // Determine if sidebar should show on desktop
  const showSidebar = currentTab === 'live-sos' || currentTab === 'incidents' || currentTab === 'locate';

  return (
    <div className="min-h-screen flex flex-col bg-[#f9f9ff] text-[#111c2d] antialiased">
      {/* Top Navigation Bar */}
      <TopNavBar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenEmergencyModal={() => setIsEmergencyModalOpen(true)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        isSosActive={isSosActive}
      />

      {/* Main Layout Container */}
      <div className="flex flex-1 w-full relative">
        {/* Sidebar Nav (Desktop only when on specific views) */}
        {showSidebar && (
          <SideNavBar
            currentTab={currentTab}
            onSelectTab={setCurrentTab}
            onNewIncident={() => {
              setInitialCategory('');
              setCurrentTab('incidents');
            }}
            isSosActive={isSosActive}
          />
        )}

        {/* View Switcher */}
        <main className={`flex-1 flex flex-col w-full min-h-[calc(100vh-64px)] transition-all ${showSidebar ? 'lg:pl-64' : ''}`}>
          {currentTab === 'welcome' && (
            <WelcomeOpeningView
              onEnterPortal={setCurrentTab}
              onTriggerSos={handleTriggerSos}
              isSosActive={isSosActive}
            />
          )}

          {currentTab === 'dashboard' && (
            <DashboardView
              advisory={advisory}
              incidents={incidents}
              facilities={facilities}
              onSelectTab={setCurrentTab}
              onTriggerSos={handleTriggerSos}
              isSosActive={isSosActive}
              onQuickCategoryClick={handleQuickCategoryClick}
              onSelectFacilityCategory={handleSelectFacilityCategory}
            />
          )}

          {currentTab === 'live-sos' && (
            <LiveSosView
              contacts={contacts}
              onCancelSos={handleCancelSos}
              onAddContact={handleAddContact}
            />
          )}

          {currentTab === 'incidents' && (
            <ReportingView
              submissions={submissions}
              onSubmitNewReport={handleSubmitNewReport}
              onUpgradeToSos={handleTriggerSos}
              initialCategory={initialCategory}
            />
          )}

          {currentTab === 'locate' && (
            <LocateView
              facilities={facilities}
              initialCategory={selectedLocateCategory}
            />
          )}
        </main>
      </div>

      {/* Shared Footer */}
      <Footer />

      {/* Emergency Call Dialog Modal */}
      <EmergencyModal
        isOpen={isEmergencyModalOpen}
        onClose={() => setIsEmergencyModalOpen(false)}
        onTriggerSos={handleTriggerSos}
      />
    </div>
  );
}
export default App;
