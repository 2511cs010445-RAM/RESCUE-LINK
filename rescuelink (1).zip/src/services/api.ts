import {
  SystemAdvisory,
  IncidentFeedItem,
  EmergencyContact,
  IncidentReportSubmission,
  NearbyFacility,
} from '../types';

export interface DiagnosticsResponse {
  gpsLock: { status: string; precision: string; accuracy: string };
  meshNetwork: { status: string; type: string; latencyMs: number };
  emergencyDispatchLine: { status: string; channel: string; availability: string };
  serverLoad: string;
  activeIncidents: number;
  activeSosBeacons: number;
}

export interface SosStatusResponse {
  sos: {
    isActive: boolean;
    triggeredAt: string | null;
    location: {
      address: string;
      lat: number;
      lng: number;
      accuracyMeters: number;
    };
    etaMinutes: number;
    notifiedContactsCount: number;
  };
}

export interface AIAnalysisResult {
  urgency: 'High' | 'Medium' | 'Low' | 'Normal';
  suggestedCategory?: string;
  keyFactors?: string[];
  recommendation?: string;
  error?: string;
}

// 1. Diagnostics & Health
export async function fetchHealth(): Promise<{ status: string; service: string }> {
  const res = await fetch('/api/health');
  if (!res.ok) throw new Error('Health check failed');
  return res.json();
}

export async function fetchDiagnostics(): Promise<DiagnosticsResponse> {
  const res = await fetch('/api/diagnostics');
  if (!res.ok) throw new Error('Diagnostics fetch failed');
  return res.json();
}

// 2. Advisories
export async function fetchAdvisory(): Promise<SystemAdvisory> {
  const res = await fetch('/api/advisories');
  if (!res.ok) throw new Error('Failed to fetch advisory');
  const data = await res.json();
  return data.advisory;
}

export async function updateAdvisory(advisory: Partial<SystemAdvisory>): Promise<SystemAdvisory> {
  const res = await fetch('/api/advisories', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(advisory),
  });
  if (!res.ok) throw new Error('Failed to update advisory');
  const data = await res.json();
  return data.advisory;
}

// 3. Incidents
export async function fetchIncidents(category?: string, search?: string): Promise<IncidentFeedItem[]> {
  const params = new URLSearchParams();
  if (category && category !== 'all') params.append('category', category);
  if (search) params.append('search', search);

  const url = `/api/incidents${params.toString() ? `?${params.toString()}` : ''}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Failed to fetch incidents');
  const data = await res.json();
  return data.incidents;
}

export async function createIncident(incident: Partial<IncidentFeedItem>): Promise<IncidentFeedItem> {
  const res = await fetch('/api/incidents', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(incident),
  });
  if (!res.ok) throw new Error('Failed to create incident');
  const data = await res.json();
  return data.incident;
}

// 4. Reports / Submissions
export async function fetchReports(): Promise<IncidentReportSubmission[]> {
  const res = await fetch('/api/reports');
  if (!res.ok) throw new Error('Failed to fetch reports');
  const data = await res.json();
  return data.submissions;
}

export async function submitReport(
  reportData: Omit<IncidentReportSubmission, 'id' | 'submittedAt' | 'status'>
): Promise<{ submission: IncidentReportSubmission; feedItem: IncidentFeedItem }> {
  const res = await fetch('/api/reports', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(reportData),
  });
  if (!res.ok) throw new Error('Failed to submit report');
  return res.json();
}

// 5. Emergency Contacts
export async function fetchContacts(): Promise<EmergencyContact[]> {
  const res = await fetch('/api/contacts');
  if (!res.ok) throw new Error('Failed to fetch contacts');
  const data = await res.json();
  return data.contacts;
}

export async function addContact(name: string, role: string, phone: string): Promise<EmergencyContact> {
  const res = await fetch('/api/contacts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, role, phone }),
  });
  if (!res.ok) throw new Error('Failed to add contact');
  const data = await res.json();
  return data.contact;
}

export async function deleteContact(id: string): Promise<void> {
  const res = await fetch(`/api/contacts/${id}`, {
    method: 'DELETE',
  });
  if (!res.ok) throw new Error('Failed to delete contact');
}

export async function broadcastTestPing(): Promise<{ message: string; contacts: EmergencyContact[] }> {
  const res = await fetch('/api/contacts/broadcast-test', {
    method: 'POST',
  });
  if (!res.ok) throw new Error('Failed to test broadcast ping');
  return res.json();
}

// 6. Emergency Facilities
export async function fetchFacilities(
  category?: string,
  search?: string,
  userLat?: number,
  userLng?: number
): Promise<NearbyFacility[]> {
  const params = new URLSearchParams();
  if (category && category !== 'all') params.append('category', category);
  if (search) params.append('search', search);
  if (userLat !== undefined && userLng !== undefined) {
    params.append('userLat', userLat.toString());
    params.append('userLng', userLng.toString());
  }

  const url = `/api/facilities${params.toString() ? `?${params.toString()}` : ''}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Failed to fetch facilities');
  const data = await res.json();
  return data.facilities;
}

// 6b. Live Reverse Geocode
export interface ReverseGeocodeResult {
  success: boolean;
  address: string;
  shortAddress: string;
  city: string;
  state: string;
  lat: number;
  lng: number;
}

export async function reverseGeocode(lat: number, lng: number): Promise<ReverseGeocodeResult> {
  const res = await fetch(`/api/location/reverse-geocode?lat=${lat}&lng=${lng}`);
  if (!res.ok) throw new Error('Failed to reverse geocode location');
  return res.json();
}

// 6c. Turn-by-Turn Directions
export interface RouteStep {
  instruction: string;
  distance: string;
  distanceMeters: number;
  durationSeconds: number;
  icon: 'straight' | 'turn-left' | 'turn-right' | 'merge' | 'destination' | 'start';
  streetName: string;
}

export interface DirectionsResult {
  success: boolean;
  route: {
    origin: { lat: number; lng: number; address: string };
    destination: { lat: number; lng: number; name: string; address: string };
    mode: 'emergency' | 'driving' | 'walking';
    totalDistanceMiles: number;
    totalDistanceText: string;
    estimatedDurationMinutes: number;
    estimatedDurationText: string;
    steps: RouteStep[];
    polylineCoords: [number, number][];
  };
}

export async function fetchDirections(params: {
  origin: { lat: number; lng: number; address?: string };
  destination?: { lat: number; lng: number; name?: string; address?: string };
  facilityId?: string;
  mode?: 'emergency' | 'driving' | 'walking';
}): Promise<DirectionsResult> {
  const res = await fetch('/api/directions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  if (!res.ok) throw new Error('Failed to fetch directions');
  return res.json();
}

// 7. SOS State
export async function fetchSosStatus(): Promise<SosStatusResponse['sos']> {
  const res = await fetch('/api/sos/status');
  if (!res.ok) throw new Error('Failed to fetch SOS status');
  const data = await res.json();
  return data.sos;
}

export async function triggerSosBeacon(location?: {
  address: string;
  lat: number;
  lng: number;
}): Promise<SosStatusResponse['sos']> {
  const res = await fetch('/api/sos/trigger', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ location }),
  });
  if (!res.ok) throw new Error('Failed to trigger SOS beacon');
  const data = await res.json();
  return data.sos;
}

export async function cancelSosBeacon(): Promise<SosStatusResponse['sos']> {
  const res = await fetch('/api/sos/cancel', {
    method: 'POST',
  });
  if (!res.ok) throw new Error('Failed to cancel SOS beacon');
  const data = await res.json();
  return data.sos;
}

// 8. AI Analysis
export async function analyzeReportWithAI(text: string, category?: string): Promise<AIAnalysisResult> {
  const res = await fetch('/api/ai/analyze-report', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text, category }),
  });
  if (!res.ok) throw new Error('Failed to analyze report with AI');
  return res.json();
}
