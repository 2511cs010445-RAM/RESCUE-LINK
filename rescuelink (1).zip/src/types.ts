export type NavigationTab = 'welcome' | 'dashboard' | 'incidents' | 'locate' | 'live-sos';

export type IncidentCategory = 'medical' | 'fire' | 'police' | 'accident' | 'hazard' | 'property' | 'suspicious' | 'welfare' | 'other';

export type IncidentStatus = 'In Review' | 'Resolved' | 'Requires Action' | 'Dispatched' | 'Active';

export interface IncidentFeedItem {
  id: string;
  title: string;
  category: IncidentCategory;
  description: string;
  timeAgo: string;
  timestamp: string;
  severityColor: string; // e.g., 'bg-[#bb0112]' | 'bg-[#f59e0b]' | 'bg-[#004ac6]'
  locationName: string;
  lat?: number;
  lng?: number;
}

export interface IncidentReportSubmission {
  id: string;
  category: string;
  description: string;
  status: IncidentStatus;
  submittedAt: string;
  location: {
    address: string;
    lat: number;
    lng: number;
  };
  hasEvidence: boolean;
  evidenceFileName?: string;
}

export interface EmergencyContact {
  id: string;
  name: string;
  role: string;
  status: 'delivered' | 'received' | 'attempting' | 'failed';
  statusMessage: string;
  phone?: string;
  timeAgo?: string;
}

export type FacilityCategory = 'hospital' | 'police' | 'fire' | 'ambulance';

export interface NearbyFacility {
  id: string;
  name: string;
  category: FacilityCategory;
  distance: string;
  address: string;
  phone: string;
  badges: string[];
  lat: number;
  lng: number;
  open24h: boolean;
}

export interface SystemAdvisory {
  id: string;
  title: string;
  description: string;
  severity: 'warning' | 'critical' | 'info';
  active: boolean;
}
